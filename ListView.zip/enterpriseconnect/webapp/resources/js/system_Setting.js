jQuery(document).ready(function($) {
var data = {}
	
	$.ajax({
		type : "POST",
		contentType : "application/json",
		url : "/enterpriseconnect/getAllSystemSettings",
		dataType : 'json',
		timeout : 100000,
		success : function(data) {
			console.log("SUCCESS:", data);
			$('#footerText').text(data.footerText)
			//$('.btn-primary').css('background-color',data.colorNavi);.list-group-horizontal .list-group-item
			
			$(".btn-primary").css("background-color",data.colorBottonBody);
			$(".btn-primary").css("border-color",data.colorBottonBorder);
			$(".navbar, .navbar-default, .navbar-static-top").css("background-color",data.colorNavi);
			$(".navbar-default .sidebar").css("background-color",data.colorNavi);
			$("footer").css("background-color",data.colorBodyL3);
			$(".breadcrumb").css("background-color",data.colorBodyL1);
			
			$(".alternate-col-highlight-tbl > tbody > tr > td:nth-child(odd),.setting-tbl > tbody > tr > td:nth-child(odd),.info-tbl > thead > tr > th,.info-tbl > thead > tr > th,.info-tbl > tbody > tr > th,.year-tbl > thead > tr > th,.total-tbl> tbody > tr > th,.year-tbl > tbody > tr:nth-child(even),.currency-tbl > thead > tr > th:first-child,.country-tbl > tbody > tr > td:nth-child(odd)").css("background-color",data.colorBodyL2);
		 
			$( '.gray-backcolor' ).each(function () {
			    this.style.setProperty( 'background-color', data.colorBodyL2, 'important' );
			});
		},
		error : function(e) {
			console.log("ERROR: ", e);
			
		},
		done : function(e) {
			console.log("DONE");
		}
	});

});





function validate_number(element){
	if(isNaN($(element).val())){
		show_error(element,strings['invalid.number']);
		return false;
	}

	hide_error(element);
	return true;
}

function requiredField(element){
	if(!$(element).val()){
		show_error(element,strings['field.required']);
		return false;
	}

	hide_error(element);
	return true;
}

function validate_string_length(element,min,max){
	 var str_length = $(element).val().length;
	 console.log(str_length)
	 if((str_length > max) || (str_length < min)){
		 show_error(element,passwordValidator(min,max));
	    return false;
	 }
	 hide_error(element);
	 return true;
	}

function validate_emailField(element){
if(!validate_email($(element).val())){
	console.log('inside email error');
	show_error(element,strings['email.invalid']);
	return false;
}
hide_error(element);
return true;
}

function show_error(element,error_statement){
	if(error_statement == undefined){
		error_statement = '';
	}
	var validation_message_element =  $(element).parent();
	var p_element = $(validation_message_element).children('p');
	$(p_element).html('<i class="fa fa-info-circle"></i>'+ error_statement)
	$(p_element).css('display','block');
	  
}

function hide_error(element){
	var validation_message_element =  $(element).parent();
	var p_element = $(validation_message_element).children('p');
	$(p_element).html('')
	$(p_element).css('display','none');
}

function edit_mode(id){
	 console.log("#"+id+'-edit-mode');
	 $("#"+id+'-edit-mode').removeClass('hidden');
	 $("#"+id).addClass('hidden');
	}

function view_mode(id){
$("#"+id+'-edit-mode').addClass('hidden');
$("#"+id).removeClass('hidden');
}

function toggle(id){
if($("#"+id).hasClass('hidden')){
 $("#"+id).removeClass('hidden')
}
else{
 $("#"+id).addClass('hidden')
 }
}


$(document).ready(function() {
           $("#datepicker-issuedate" ).datepicker({format: "yyyy/mm/dd"});
           $("#datepicker-validdate").datepicker({format: "yyyy/mm/dd"});
           $("#datepicker-startdate").datepicker({format: "yyyy/mm/dd"});
           $("#datepicker-enddate").datepicker({format: "yyyy/mm/dd"});
           $(".resource").val("");
           $( "#datepicker-issuedate" ).change(function() {
             $("#datepicker-issuedate" ).datepicker({format: "yyyy/mm/dd"});
               $("#datepicker-validdate").datepicker({format: "yyyy/mm/dd"});
             var result = new Date($( "#datepicker-issuedate" ).val());
                result.setDate(result.getDate() + 15);
             $( "#datepicker-validdate" ).val(result.getFullYear()+ '/' +(result.getMonth() + 1) + '/' + result.getDate());
            });
           getProjDate();
           getCountryClientList();
           $(".country").each(function() {
             if($(this).val() == "${defaultCountry}"){
               $(this).addClass("selected bold-font");
             }
           });
           function getCountryClientList() {
               var data = {}
               data["countryName"] = $("#countryField").val();
               $.ajax({
            	   beforeSend : function(){
      			       $('#spinner').show()
      			   },
      			  complete : function(){
      			       $('#spinner').hide();
      			  },
                 type : "POST",
                 url : contextPath+"/countryClientlist",
                 data : data,
                 timeout : 100000,
                 success : function(data) {
                	 $("#client").empty();
                	 $.each(data,function(i,val) {
                         $("#client").append(($('<option>', {value:val['clientProfileId'], text:val['companyName']})));
                    });
                	 getClientDetails();
                 },
                 error : function(e) {
                   console.log("ERROR: ", e);
                   alert(e.responseText);
                 },
                 done : function(e) {
                   console.log("DONE");
                 }
               });
             }
           $(".template").on("click", function () {
             var no = $("#mgmtNo").text();
                var $newPanel = $("#dataRow").clone();
                $newPanel.find('input').each(function() {
                    this.name= this.name.replace(/[0-9]+/, no);
                    this.id= this.id.replace(/[0-9]+/, no);
                    this.value = "";
                });
                $newPanel.find("span.number").html(no);
                no = parseInt(no) + 1;
                $("#mgmtNo").html(no);
           $("#tblBody").append($newPanel.fadeIn());
          });
           $(".rate,.resource").keyup(function() {   
                  calculateSum();
              });
           $(document).on('keyup', '.rate , .resource', function () {
             calculateSum();
            });
           $(document).on('keyup', ':checkbox', function () {
             calculateSum();
            });
           $(':checkbox').change(function() {
              calculateSum();
           });
           $('#taxValue,#mgmt').change(function() {
             calculateSum();
          });
           $('#client').change(function() {
        	   getProjectDetails();
        	   alert("before project date");
        	   getProjDate();
            });
          // Country click 
           $(".country").on("click", function () {
             $("#countryField").val($(this).text());
             $("#seal").val($(this).text());
             $("#logo").val($(this).text());
             //$(".country").html($(this).text()); 
             getCurrencySymbol();
             $("table.select-tbl tr td.con.selected" ).removeClass("selected bold-font");
             $(this).parent().addClass("selected bold-font");
           });
          // Save click - Workdata validations
           $("#save").on("click", function () {
        	   var error = true;
             $(".rate").each(function() {
               var index = $(this).attr('name').split('workData')[1].split('.')[0];
                   //add only if the value is number
               var particular = $("#particular" + index ).val();
               var resource = $("#resource" + index ).val();
               
               if (!isNaN($(this).val()) && $(this).val().length != 0) {
                 if (!(!isNaN(resource) && resource.length != 0 && particular.length != 0)) {
                   error = false;
                   $("#error" + index ).html(' <p class="help-block"><i class="glyphicon glyphicon-info-sign"></i>Workdata should have particular, resources, rate.</p>');
                   }  
                 } else {
                     if (!((isNaN(resource) || resource.length == 0) && particular.length == 0)) {
                       $("#error" + index ).html(' <p class="help-block"><i class="glyphicon glyphicon-info-sign"></i>Workdata should have particular, resources, rate.</p>');
                       error = false;  
                     }
                   }  
             });
             return error;
             });
         });
         // Sum calculation on key up and down
         function calculateSum() {
              var sum = 0;
              var taxAmt = 0;
              var tax = $("#taxValue").val();
              var mgmt = $("#mgmt").val();
              //iterate through each textboxes and add the values
              $(".rate").each(function() {
                
                  //add only if the value is number
                  if (!isNaN($(this).val()) && $(this).val().length != 0) {
                    var index = $(this).attr('name').split('workData')[1].split('.')[0];
                    var amnt = parseFloat($(this).val()) * parseFloat($("#resource" + index ).val());
                    if (!isNaN(amnt)){
                    if($("#tax" + index).is(':checked')) {
                      taxAmt = taxAmt + parseFloat((amnt * tax/100));
                    }
                    $("#amount" + index).val(amnt.toFixed(2) );
                      sum += parseFloat(amnt);
                      $("#amount" + index).css("background-color", "#FEFFB0");
                    }
                  }
              });
             
              var mgmtAmt = parseFloat((sum * mgmt/100));
              sum = sum + mgmtAmt;
              $("#subTotal").html(sum.toFixed(2));
              if($("#mgmtTax").is(':checked')) {
                
                var mgmtTaxAmnt = parseFloat((mgmtAmt * tax/100));
                taxAmt = taxAmt + mgmtTaxAmnt;
                sum = sum + mgmtTaxAmnt + taxAmt;
            }else {
              sum = sum + taxAmt;
            }
              $("#taxAmnt").html(taxAmt.toFixed(2));
              $("#total").html(sum.toFixed(2));
              $("#estimationAmount").val(sum.toFixed(2));
          }
         function getProjDate(){
           var data = {}
           data["id"] = $("#project").val();
           $.ajax({
                 type : "POST",
                 url : contextPath + "/billingestimates/projectData",
                 data : data,
                 timeout : 100000,
                 success : function(data) {
                   console.log("SUCCESS: ", data);
                   data = data.split(":");
                   if(data.length > 1){
                   $("#datepicker-startdate").val(data[0]);
               $("#datepicker-enddate").val(data[1]);
                   }else{
                	   $("#datepicker-startdate").val("");
                	   $("#datepicker-enddate").val("")
                   }
                 },
                 error : function(e) {
                   console.log("ERROR: ", e);
                   alert(e);
                 },
                 done : function(e) {
                   console.log("DONE");
                 }
               });
         }
           function getCurrencySymbol(){
               var data = {}
               data["name"] = $("#countryField").val();
               $.ajax({
            	   beforeSend : function(){
      			       $('#spinner').show()
      			   },
      			  complete : function(){
      			       $('#spinner').hide();
      			  },
                     type : "POST",
                     url : contextPath + "/billingestimates/currencySymbol",
                     data : data,
                     timeout : 100000,
                     success : function(data) {
                       console.log("SUCCESS: ", data);
                       $(".currency").html(data["currencySymbol"]);
                       $(".tax").empty();
                       $.each(data["tax"],function(i,val) {
                           	var tax = val["tax"];
                            var taxName = val["taxName"];
                            $(".tax").append(($('<option>', {value:tax, text:taxName+" - "+tax+" %"})));
                       });
                       $("#client").empty();
                       $.each(data["clientProfile"],function(i,val) {
                           	var companyName = val["companyName"];
                            var clientProfileId = val["clientProfileId"];
                            $("#client").append(($('<option>', {value:clientProfileId, text:companyName})));
                       });
                     },
                     error : function(e) {
                       console.log("ERROR: ", e);
                       alert(e);
                     },
                     done : function(e) {
                       console.log("DONE");
                     }
                   });
         }
           function getProjectDetails(){
               var data = {}
               data["id"] = $("#client").val();
               $.ajax({
            	   beforeSend : function(){
      			       $('#spinner').show()
      			   },
      			  complete : function(){
      			       $('#spinner').hide();
      			  },
                     type : "POST",
                     url : contextPath + "/projectDetails",
                     data : data,
                     timeout : 100000,
                     success : function(data) {
                    	 $("#project").empty();
                         $.each(data,function(i,val) {
                             	var companyName = val["projectId"];
                              var clientProfileId = val["projectName"];
                              $("#project").append(($('<option>', {value:companyName, text:clientProfileId})));
                         });
                     },
                     error : function(e) {
                       console.log("ERROR: ", e);
                       alert(e.responseText);
                     },
                     done : function(e) {
                       console.log("DONE");
                     }
                   });
           }
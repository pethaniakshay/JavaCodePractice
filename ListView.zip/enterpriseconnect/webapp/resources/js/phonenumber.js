function validate_phone_number(phone_number,country){
	if(country == 'INDIA'){
		//+91-xx-xxxx-xxxx   <here x must be a number >
		var matches = /^(\+91)[-][0-9]{2}[-][0-9]{4}[-][0-9]{4}$/.exec(phone_number);
	    if (matches == null) return false;
	    return true;	
	}
	if(country == 'USA'){
		//+1-xx-xxxx-xxxx   <here x must be a number >
		var matches = /^(\+1)[-][0-9]{2}[-][0-9]{8}$/.exec(phone_number);
	    if (matches == null) return false;
	    return true;
	}
	if(country == 'JAPAN'){
		//+81-xx-xxxx-xxxx   <here x must be a number >
		var matches = /^(\+81)[-][0-9]{2}[-][0-9]{4}[-][0-9]{4}$/.exec(phone_number);
	    if (matches == null) return false;
	    return true;	
	}
}


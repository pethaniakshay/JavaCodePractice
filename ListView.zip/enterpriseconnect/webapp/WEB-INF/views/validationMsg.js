function loadMessages(){
strings['email.invalid'] = "<spring:message code='email.invalid' javaScriptEscape='true' />";
strings['invalid.website'] = "<spring:message code='invalid.website' javaScriptEscape='true' />";
strings['field.required'] = "<spring:message code='field.required' javaScriptEscape='true' />";
strings['invalid.number'] = "<spring:message code='invalid.number' javaScriptEscape='true' />";
}

function passwordValidator(min,max){
	return  "<spring:message code='field.password.length' arguments='${min};${max}' javaScriptEscape='true' />";
}
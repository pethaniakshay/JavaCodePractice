/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.web.UserController;

public class FeedSuccessHandler implements AuthenticationSuccessHandler {

  private final Logger logger = LoggerFactory
      .getLogger(FeedSuccessHandler.class);
  
  @Autowired
  private UserService userService;

  /**
     * Authentication success method
     * 
     * @param request
     * @param response
     * @param authentication
     * @return
     */
  public void onAuthenticationSuccess(HttpServletRequest request,
      HttpServletResponse response, Authentication authentication)
      throws IOException, ServletException {
    String selectedLocale = request.getParameter("language");
    logger.info(" Locale from request :" + selectedLocale);
    if (selectedLocale != null && selectedLocale.equalsIgnoreCase("jp")) {
      logger.info("Application Locale is set to japanese");
      response.sendRedirect(request.getContextPath() + "/dashboard?language="
          + selectedLocale);
    } else {
      response.sendRedirect(request.getContextPath() + "/dashboard");
    }
  }
}

/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.validator;

import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.web.UserController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * Sample User validator- needs to be updated later
 * 
 * @author anand
 *
 */
@Component
public class ProjectValidator implements Validator {
    @Autowired
    private UserService userService;
    
    private final Logger logger = LoggerFactory.getLogger(ProjectValidator.class);

    @Override
    public boolean supports(Class<?> aClass) {
        return Project.class.equals(aClass);
    }

    /**
     * Override validate method
     * 
     * @param Object
     * @param errors
     *
     */
    @Override
    public void validate(Object o, Errors errors) {
      Project project = (Project) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "projectName", "NotEmpty");
        logger.debug("Validator :"  + project.getProjectName());
        /*if (!estimation.getEstimationAmount().matches("^[0-9]*$")) {
          logger.debug("Validator Error" );
            errors.rejectValue("estimationAmount", "estimation.amount.type");
        }*/
        
    }
}

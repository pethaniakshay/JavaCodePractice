package com.erai.enterpriseconnect.display;

import java.io.Serializable;
import java.util.List;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.MasterTax;

public class CountryDisplay implements Serializable {
  
  private String currencySymbol;
  private List<MasterTax> tax;
  private List<ClientDisplay> clientProfile;
  
  public List<ClientDisplay> getClientProfile() {
    return clientProfile;
  }
  public void setClientProfile(List<ClientDisplay> clientProfile) {
    this.clientProfile = clientProfile;
  }
  public String getCurrencySymbol() {
    return currencySymbol;
  }
  public void setCurrencySymbol(String currencySymbol) {
    this.currencySymbol = currencySymbol;
  }
  public List<MasterTax> getTax() {
    return tax;
  }
  public void setTax(List<MasterTax> tax) {
    this.tax = tax;
  }
 

}

package com.erai.enterpriseconnect.display;

public class EstimationJSON {
  
  public int getNo() {
    return no;
  }
  public void setNo(int no) {
    this.no = no;
  }
  public String getEstimationId() {
    return estimationId;
  }
  public void setEstimationId(String estimationId) {
    this.estimationId = estimationId;
  }
  public String getIssueDate() {
    return issueDate;
  }
  public void setIssueDate(String issueDate) {
    this.issueDate = issueDate;
  }
  public String getCompany() {
    return company;
  }
  public void setCompany(String company) {
    this.company = company;
  }
  public String getProject() {
    return project;
  }
  public void setProject(String project) {
    this.project = project;
  }
  public String getAmount() {
    return amount;
  }
  public void setAmount(String amount) {
    this.amount = amount;
  }
  private int no;
  private String estimationId;
  private String issueDate;
  private String company;
  private String project;
  private String amount;

}

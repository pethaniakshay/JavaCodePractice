package com.erai.enterpriseconnect.display;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.MasterContractType;
import com.erai.enterpriseconnect.model.MasterTax;

public class ProjectDisplay implements Serializable {
  private Long projectId;
  private String projectName;
  private String masterContractTypeId;
  private String projectVol;
  private String startDate;
  private String endDate;
  
  public Long getProjectId() {
    return projectId;
  }
  public void setProjectId(Long projectId) {
    this.projectId = projectId;
  }
  public String getProjectName() {
    return projectName;
  }
  public void setProjectName(String projectName) {
    this.projectName = projectName;
  }

  public String getMasterContractTypeId() {
    return masterContractTypeId;
  }
  public void setMasterContractTypeId(String masterContractTypeId) {
    this.masterContractTypeId = masterContractTypeId;
  }
  public String getProjectVol() {
    return projectVol;
  }
  public void setProjectVol(String projectVol) {
    this.projectVol = projectVol;
  }
  public String getStartDate() {
    return startDate;
  }
  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }
  public String getEndDate() {
    return endDate;
  }
  public void setEndDate(String endDate) {
    this.endDate = endDate;
  }

}

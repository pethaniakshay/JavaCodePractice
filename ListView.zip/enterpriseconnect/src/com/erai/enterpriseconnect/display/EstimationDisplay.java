package com.erai.enterpriseconnect.display;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.model.MasterTax;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;

public class EstimationDisplay implements Serializable {
  private String estimationAmount;
  private MasterPaymentTerms masterPaymentTerms;
  private ProjectDisplay project;
  private String poNumber;
  private List<WorkDataDisplay> workData = new ArrayList<WorkDataDisplay>();
  
  public String getEstimationAmount() {
    return estimationAmount;
  }
  public void setEstimationAmount(String estimationAmount) {
    this.estimationAmount = estimationAmount;
  }
  public MasterPaymentTerms getMasterPaymentTerms() {
    return masterPaymentTerms;
  }
  public void setMasterPaymentTerms(MasterPaymentTerms masterPaymentTerms) {
    this.masterPaymentTerms = masterPaymentTerms;
  }
  public ProjectDisplay getProject() {
    return project;
  }
  public void setProject(ProjectDisplay project) {
    this.project = project;
  }
  public String getPoNumber() {
    return poNumber;
  }
  public void setPoNumber(String poNumber) {
    this.poNumber = poNumber;
  }
  public List<WorkDataDisplay> getWorkData() {
    return workData;
  }
  public void setWorkData(List<WorkDataDisplay> workData) {
    this.workData = workData;
  }


}

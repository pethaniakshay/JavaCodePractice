/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;

import java.io.File;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.core.util.RequestUtil;
import com.erai.enterpriseconnect.core.util.VelocityUtil;
import com.erai.enterpriseconnect.display.ClientDisplay;
import com.erai.enterpriseconnect.display.CountryDisplay;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Invoice;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.WorkData;
import com.erai.enterpriseconnect.service.BillingsService;
import com.erai.enterpriseconnect.service.InvoiceService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CountryService;
import com.erai.enterpriseconnect.service.MasterTaxService;
import com.erai.enterpriseconnect.service.ProjectService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.EstimationValidator;
import com.erai.enterpriseconnect.validator.InvoiceValidator;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * SalesConnect controller for sales connect
 * 
 * @author anand
 *
 */
@Controller
@RequestMapping(value = "/invoice")
public class InvoiceController {

  private final Logger logger = LoggerFactory
      .getLogger(InvoiceController.class);

  @Autowired
  private InvoiceValidator invoiceValidator;
  
  @Autowired
  private ServletContext serContext;

  @Autowired
  private InvoiceService invoiceService;
  
  @Autowired
  private BillingsService billingsService;

  @Autowired
  private UserService userService;
  
  @Autowired
  private ProjectService projectService;
  
  @Autowired
  private CountryService countryService;

  @Autowired
  private SecurityService securityService;
  
  @Autowired
  private MasterTaxService masterTaxService;

  @Autowired
  private ClientProfileService clientProfileService;
  
  @Autowired
  private UserValidator userValidator;

  @Autowired
  private MessageSource messageSource;

  @Autowired
  private VelocityUtil velocityUtil;
  
  @Value("${application.dateFormat}")
  private String dateFormat;
  
  private DecimalFormat df;
  
  private SimpleDateFormat sd;
  
  @PostConstruct
  public void initialize() {
    Locale locale = LocaleContextHolder.getLocale();
    df = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(locale));
    sd = new SimpleDateFormat(dateFormat);
  }
  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/", method = RequestMethod.GET)
  public String list(Model model) {
    Locale locale = LocaleContextHolder.getLocale();
    model.addAttribute("isSalesconnect", "true");
    Map<String, Object> invValues = invoiceService.listInvoice();
    // Values to view
    model.addAttribute("invoices", invValues.get("invoices"));
    model.addAttribute("year", invValues.get("year"));
    model.addAttribute("countryList", invValues.get("countryList"));
    model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
    logger.debug("dateFormat:" + dateFormat);
    model.addAttribute("dateFormat", dateFormat);
    return "invoices_list";
  }

  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/create", method = RequestMethod.GET)
  public String create(Model model) {
    model.addAttribute("isSalesconnect", "true");
    Invoice inv = null;
    if(model.asMap().get("invoice")!= null){
      inv = (Invoice) model.asMap().get("invoice");
    } else {
      inv = new Invoice();
    }
    // Error Handling
    if(model.asMap().get("error")!= null){
      logger.debug("error:" + model.asMap().get("error"));
      model.addAttribute("error", model.asMap().get("error"));
    }
    // Business Logic
    Map<String, Object> invValues = invoiceService.createInvoice(inv);
    
    // Setting values to view
    model.addAttribute("clients", invValues.get("clients"));
    model.addAttribute("contractTypes", invValues.get("contractTypes"));
    model.addAttribute("paymentTerms", invValues.get("paymentTerms"));
    model.addAttribute("projects", invValues.get("projects"));
    model.addAttribute("projectVolumes", invValues.get("projectVolumes"));
    model.addAttribute("countries",invValues.get("countries") );
    model.addAttribute("defaultCountry",invValues.get("defaultCountry") );
    model.addAttribute("defaultCurrency",invValues.get("defaultCurrency"));
    model.addAttribute("invoice", inv);
    model.addAttribute("taxList", invValues.get("taxList"));
    model.addAttribute("dateFormat", dateFormat);
    return "billings_inv_create";
  }

  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/viewRecord/{id}", method = RequestMethod.GET)
  public String viewRecord(@PathVariable("id") String id, Model model) {
    model.addAttribute("isSalesconnect", "true");
    // Business Logic -URL parameter is encrypted to avoid tampering
    logger.debug("id :"+ id);
    id = EncrptBean.decrypt(id);
    Invoice inv = invoiceService.findByInvoiceId(id);
    Map<String, Object> estView = invoiceService.viewInvoice(inv);
   
    // Display Logic
    model.addAttribute("invoice", estView.get("invoice"));
    model.addAttribute("countryList", estView.get("countryList"));
    model.addAttribute("mgmtData", estView.get("mgmtData"));
    model.addAttribute("taxPercent", estView.get("taxPercent"));
    model.addAttribute("subTotal", df.format(Double.parseDouble(estView.get("subTotal")+"")));
    model.addAttribute("tax", df.format(Double.parseDouble(estView.get("tax")+"")));
    model.addAttribute("total", df.format(Double.parseDouble(estView.get("total")+"")));
    model.addAttribute("defaultCurrency",estView.get("defaultCurrency"));
    model.addAttribute("defaultCountry",estView.get("defaultCountry"));
    model.addAttribute("dateFormat", dateFormat);
    return "billings_inv_view";
  }
  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
  public String edit(@PathVariable("id") String id, Model model) {
    model.addAttribute("isSalesconnect", "true");
    model.addAttribute("isEdit", "true");
    Invoice inv = invoiceService.findByInvoiceId(id);
    Map<String, Object> invValues = invoiceService.viewInvoice(inv);
    Map<String, Object> estCreate = invoiceService.createInvoice(inv);
    invValues.putAll(estCreate);
    model.addAttribute("invoice", invValues.get("invoice"));
    model.addAttribute("countryList", invValues.get("countryList"));
    model.addAttribute("subTotal", invValues.get("subTotal"));
    model.addAttribute("tax", invValues.get("tax"));
    model.addAttribute("total", invValues.get("total"));
    model.addAttribute("clients", invValues.get("clients"));
    model.addAttribute("contractTypes", invValues.get("contractTypes"));
    model.addAttribute("paymentTerms", invValues.get("paymentTerms"));
    model.addAttribute("projects", invValues.get("projects"));
    model.addAttribute("projectVolumes", invValues.get("projectVolumes"));
    model.addAttribute("countries",invValues.get("countries") );
    model.addAttribute("defaultCurrency",invValues.get("defaultCurrency"));
    model.addAttribute("defaultCountry",invValues.get("defaultCountry"));
    model.addAttribute("mgmtData",invValues.get("mgmtData"));
    model.addAttribute("taxPercent",invValues.get("taxPercent"));
    model.addAttribute("taxList", invValues.get("taxList"));
    return "billings_est_create";
  }
  /**
   * Sample method in skeleton - needs modification
   * 
   * @param model
   * @return
   */
  @RequestMapping(value = "/save", method = RequestMethod.POST)
  public String save(Model model,
      @ModelAttribute("invoice") Invoice invoice,
      BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
    logger.debug("save method starts:");
    logger.info("param map :" + request.getParameterMap());
    invoiceValidator.validate(invoice, bindingResult);
    if (bindingResult.hasErrors()) {
      logger.error("Error : " + bindingResult.getAllErrors().get(0));
      attr.addFlashAttribute("org.springframework.validation.BindingResult.invoice", bindingResult);
      String[] args = {bindingResult.getAllErrors().get(0).toString()};
      attr.addFlashAttribute("error", messageSource.getMessage("MSGSI003",args,request.getLocale()));
      attr.addFlashAttribute("invoice", invoice);
      return "redirect:/invoice/create";
    }
    Set<WorkData> workDataSet = invoiceService.getWorkData(request.getParameterMap());
    model.addAttribute("isSalesconnect", "true");
    String countryCode = request.getParameterMap().get("selectedCountry").length > 0 ? request.getParameterMap().get("selectedCountry")[0]:"";
    if(workDataSet.size() == 0){
      attr.addFlashAttribute("error", messageSource.getMessage("MSGSI001",null,request.getLocale()));
      attr.addFlashAttribute("invoice", invoice);
      logger.debug("date:" + invoice.getDateOfIssue());
      return "redirect:/invoice/create";
    }
    String estId = request.getParameter("estimation.id");
    invoice.setEstimation(billingsService.findById(estId));
    String poNumber = request.getParameter("estimation.poNumber");
    invoice.getEstimation().setPoNumber(poNumber);
    logger.info("poNumber :" + invoice.getEstimation().getPoNumber());
    invoice.setInvoiceAmount(request.getParameter("invoiceAmount"));
    invoiceService.saveInvoice(workDataSet,invoice,countryCode);
    logger.info("invoice is saved." + invoice);
    attr.addFlashAttribute("message", "MSGSI002");
    attr.addFlashAttribute("invId", invoice.getInvoiceId());
    return "redirect:/invoice/";
  }

  @RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
  public String update(@PathVariable("id") String id,Model model,
      @ModelAttribute("invoice") Invoice invoice,
      BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
    logger.debug("update method starts:");
    Invoice inv = invoiceService.findByInvoiceId(id);
    invoiceValidator.validate(invoice, bindingResult);
    if (bindingResult.hasErrors()) {
      logger.error("Error : " + bindingResult.getAllErrors().get(0));
      attr.addFlashAttribute("org.springframework.validation.BindingResult.invoice", bindingResult);
      attr.addFlashAttribute("invoice", invoice);
      return "redirect:/billingestimates/edit";
    }
    Set<WorkData> workDataSet = invoiceService.getWorkData(request.getParameterMap());
    model.addAttribute("isSalesconnect", "true");
    if(workDataSet.size() == 0){
      attr.addFlashAttribute("error", "Atleast 1 valid Workdata required");
      attr.addFlashAttribute("invoice", invoice);
      logger.debug("date:" + invoice.getDateOfIssue());
      return "redirect:/billingestimates/edit/${invoice.id}";
    }
    String countryCode = request.getParameterMap().get("selectedCountry").length > 0 ? request.getParameterMap().get("selectedCountry")[0]:"";
    invoiceService.updateInvoice(workDataSet, invoice, inv, countryCode);
    return "redirect:/billingestimates/";
  }

  @RequestMapping(value = "/search", method = RequestMethod.POST)
  @ResponseBody
  public String search(@RequestParam String country, @RequestParam String year,
      @RequestParam String month, @RequestParam String pageSize) {
    logger.debug("start invoice search action");
    
    String data = "error";
    String role = securityService.findLoggedInUserRole();
    logger.debug("country:" + country);
    List<Invoice> invList = invoiceService.searchEstList(year, country, month,role);
   
    double sum = 0.0d;
    double balSum = 0.0d;
    double estSum = 0.0d;
    List<Estimation> estList = new ArrayList<Estimation>();
    Map<Estimation,Double> estBal = new HashMap<Estimation,Double>();
    for(Invoice inv : invList){
      String amnt = inv.getInvoiceAmount();
      String bal = inv.getBalance();
      String estAmount = null;
      if(estList.contains(inv.getEstimation())){
        estAmount = "0.00";
        if(Double.parseDouble(bal) < estBal.get(inv.getEstimation())){
          estBal.put(inv.getEstimation(), Double.parseDouble(bal));
        }
      }else {
       estAmount = inv.getEstimation().getEstimationAmount();
       inv.getEstimation().setEstimationAmount(df.format(Double.parseDouble(estAmount)));
       estList.add(inv.getEstimation());
       estBal.put(inv.getEstimation(), Double.parseDouble(bal));
      }
      sum = sum + Double.parseDouble(amnt);
      //balSum = balSum + Double.parseDouble(bal);
      estSum = estSum + Double.parseDouble(estAmount);
      inv.setInvoiceAmount(df.format(Double.parseDouble(amnt)));
      inv.setBalance(df.format(Double.parseDouble(bal)));
      inv.setFormattedDate(sd.format(inv.getDateOfIssue()));
    }
    for (Entry<Estimation, Double> entry : estBal.entrySet()) {
      balSum = balSum + entry.getValue();
    }
    try {
      int pageSizeInt = Integer.parseInt(pageSize);
      Template template = velocityUtil.getTemplate("templates/billing_inv.vm");
      VelocityContext context = new VelocityContext();
      context.put("invoices", invList);
      Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN)? true : false;
      context.put("currency",countryService.findByCountryName(country).getMstCountry().getCurrencySymbol());
      context.put("isAdmin", isAdmin);
      context.put("totalInv", df.format(sum));
      context.put("totalEst", df.format(estSum));
      context.put("totalBal", df.format(balSum));
      context.put("userType", role);
      context.put("lstSize", invList.size());
      context.put("pageSize", pageSizeInt);
      context.put("contextPath", serContext.getContextPath());
      data = velocityUtil.getData(context, template);
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    return data;
  }

  @RequestMapping(value = "/searchInvoices", method = RequestMethod.GET)
  public String searchEstimates(Model model) {
    model.addAttribute("isSalesconnect", "true");
    Locale locale = LocaleContextHolder.getLocale();
    Map<String, Object> invValues = invoiceService.search();
    model.addAttribute("invoices", invValues.get("invoices"));
    model.addAttribute("userProfile", invValues.get("userProfile"));
    model.addAttribute("userProfiles", invValues.get("userProfiles"));
    model.addAttribute("clientProfiles", invValues.get("clientProfiles"));
    model.addAttribute("countryList", invValues.get("countryList"));
    model.addAttribute("year", invValues.get("year"));
    model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
    return "billings_inv_search";
  }

  @RequestMapping(value = "/projectData", method = RequestMethod.POST)
  @ResponseBody
  public String search(@RequestParam String id) {
    logger.debug("start projectData ");
    String data = "";
    if(!StringUtils.isEmpty(id)){
    long projId = Long.parseLong(id);
    Project proj = projectService.findByProjectId(projId);
    if (proj != null) {
      data = new SimpleDateFormat("yyyy/MM/dd").format(proj.getStartDate())
          + ":" + new SimpleDateFormat("yyyy/MM/dd").format(proj.getEndDate());
    }
    }
    return data;
  }
  
  @RequestMapping(value = "/currencySymbol", method = RequestMethod.POST)
  @ResponseBody
  public CountryDisplay currencySymbol(@RequestParam String name) {
    logger.debug("start getCurrencySymbol ");
    CountryDisplay data = new CountryDisplay();
    Country country = countryService.findByCountryName(name);
    List<ClientProfile> clientProfile = clientProfileService.getClients(country);
    logger.debug("clientProfile " + clientProfile.size());
    List<ClientDisplay> clientDisplay = new ArrayList<ClientDisplay>();
    for(ClientProfile cp : clientProfileService.getClients(country)){
      ClientDisplay cd = new ClientDisplay();
      cd.setClientProfileId(cp.getClientProfileId());
      cd.setCompanyName(cp.getCompanyName());
      clientDisplay.add(cd);
    }
    if(country != null){
      data.setCurrencySymbol( country.getMstCountry().getCurrencySymbol());
      data.setTax(masterTaxService.findByMstCountry(country.getMstCountry()));
      data.setClientProfile(clientDisplay);
    }
    return data;
  }
  
  @RequestMapping(value = "/searchInvAjax", method = RequestMethod.POST)
  @ResponseBody
  public String searchInvAjax(@RequestParam String country,
      @RequestParam String year, @RequestParam String client,
      @RequestParam String user) {
    logger.debug("start searchInvAjax action");
    String data = "error";
    List<Invoice> invList = invoiceService.searchEstListAjax(year, country, client, user);
    
    double sum = 0.0d;
    double balSum = 0.0d;
    double estSum = 0.0d;
    List<Estimation> estList = new ArrayList<Estimation>();
    Map<Estimation,Double> estBal = new HashMap<Estimation,Double>();
    for(Invoice inv : invList){
      String amnt = inv.getInvoiceAmount();
      String bal = inv.getBalance();
      String estAmount = null;
      if(estList.contains(inv.getEstimation())){
        estAmount = "0.00";
        if(Double.parseDouble(bal) < estBal.get(inv.getEstimation())){
          estBal.put(inv.getEstimation(), Double.parseDouble(bal));
        }
      }else {
       estAmount = inv.getEstimation().getEstimationAmount();
       inv.getEstimation().setEstimationAmount(df.format(Double.parseDouble(estAmount)));
       estList.add(inv.getEstimation());
       estBal.put(inv.getEstimation(), Double.parseDouble(bal));
      }
      sum = sum + Double.parseDouble(amnt);
      //balSum = balSum + Double.parseDouble(bal);
      estSum = estSum + Double.parseDouble(estAmount);
      inv.setInvoiceAmount(df.format(Double.parseDouble(amnt)));
      inv.setBalance(df.format(Double.parseDouble(bal)));
      inv.setFormattedDate(sd.format(inv.getDateOfIssue()));
    }
    for (Entry<Estimation, Double> entry : estBal.entrySet()) {
      balSum = balSum + entry.getValue();
    }
    try {
      int yearInt = Integer.parseInt(year);
      String finYear = yearInt + "-" + ((yearInt + 1)+"").substring(2);
      logger.debug("year :" + yearInt);
      Template template = velocityUtil.getTemplate("templates/billing_inv_search.vm");
      VelocityContext context = new VelocityContext();
      context.put("invoices", invList);
      Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN)? true : false;
      context.put("currency",countryService.findByCountryName(country).getMstCountry().getCurrencySymbol());
      context.put("isAdmin", isAdmin);
      context.put("totalInv", df.format(sum));
      context.put("totalEst", df.format(estSum));
      context.put("totalBal", df.format(balSum));
      context.put("userType", securityService.findLoggedInUserRole());
      context.put("finYear", finYear);
      context.put("lstSize", invList.size());
      data = velocityUtil.getData(context, template);
    } catch (Exception e) {
      logger.error("Error :" + e);
    }
    return data;
  }
  
  @RequestMapping(value = "/pdf/{id}", method = RequestMethod.GET)
  public void pdf(@PathVariable("id") String id, Model model, HttpServletRequest request, HttpServletResponse response) {
    Invoice inv = invoiceService.findByInvoiceId(id);
    String data = null;
    File logo = new File("resources/images/logo_red_transparent.png");
    if(! logo.exists()){
        logger.warn("File " + logo.getName() + " not exists");
        logger.debug("Real Path :" + serContext.getRealPath("resources/images/"));
    }
    double mgmtTax = 0.0;
    double tax = 0.0;
    Map<String,Object> pdfData = invoiceService.viewInvoice(inv);
    
    for(WorkData wk : inv.getWorkData()){
      double amnt = Double.parseDouble(wk.getRate()) * wk.getNoOfResources();
      wk.setAmount(df.format(amnt));
    }
    
    try {
      Template template = velocityUtil.getTemplate("templates/invoice_pdf.vm");
      VelocityContext vcontext = new VelocityContext();
      vcontext.put("inv", inv);
      vcontext.put("dateOfIssue", sd.format(inv.getDateOfIssue()));
      vcontext.put("startDate", sd.format(inv.getProject().getStartDate()));
      vcontext.put("endDate", sd.format(inv.getProject().getEndDate()));
      vcontext.put("payDate", sd.format(inv.getPlannedPayDate()));
      if(pdfData.get("mgmtData")!= null){
        vcontext.put("mgmtData", ((WorkData) pdfData.get("mgmtData")));
      }
      vcontext.put("tax", pdfData.get("tax"));
      vcontext.put("taxPercent", df.format(Double.parseDouble(pdfData.get("taxPercent")+"")));
      vcontext.put("subTotal", df.format(Double.parseDouble(pdfData.get("subTotal")+"")));
      vcontext.put("total", df.format(Double.parseDouble(pdfData.get("total")+"")));
      vcontext.put("count", inv.getWorkData().size());
      if(!pdfData.get("defaultCountry").equals(Constants.COUNTRY_INDIA)){
      vcontext.put("defaultCurrency",  pdfData.get("defaultCurrency"));
      }
      data = velocityUtil.getData(vcontext, template);
      ITextRenderer renderer = new ITextRenderer();
      logger.debug("Base URL: " + RequestUtil.getBaseUrl(request));
      renderer.setDocumentFromString(data,RequestUtil.getBaseUrl(request)+"resources/images/");
      renderer.layout();
      OutputStream os =  response.getOutputStream();
      renderer.createPDF(os);
      os.close();
    } catch (Exception e) {
      logger.error("Error :" , e);
    }
  }
    @RequestMapping(value = "/createDuplicate/{id}", method = RequestMethod.GET)
    public String createDuplicate(@PathVariable("id") String id, Model model) {
      model.addAttribute("isSalesconnect", "true");
      model.addAttribute("isDuplicate", "true");
      Invoice inv = invoiceService.findByInvoiceId(id);
      Map<String, Object> invValues = invoiceService.viewInvoice(inv);
      Map<String, Object> estCreate = invoiceService.createInvoice(inv);
      invValues.putAll(estCreate);
      Invoice dummyEstimation = (Invoice) invValues.get("invoice");
      dummyEstimation.setInvoiceId("");
      model.addAttribute("invoice", dummyEstimation);
      model.addAttribute("countryList", invValues.get("countryList"));
      model.addAttribute("subTotal", invValues.get("subTotal"));
      model.addAttribute("tax", invValues.get("tax"));
      model.addAttribute("total", invValues.get("total"));
      model.addAttribute("clients", invValues.get("clients"));
      model.addAttribute("contractTypes", invValues.get("contractTypes"));
      model.addAttribute("paymentTerms", invValues.get("paymentTerms"));
      model.addAttribute("projects", invValues.get("projects"));
      model.addAttribute("projectVolumes", invValues.get("projectVolumes"));
      model.addAttribute("countries",invValues.get("countries") );
      model.addAttribute("defaultCurrency",invValues.get("defaultCurrency"));
      model.addAttribute("defaultCountry",invValues.get("defaultCountry"));
      model.addAttribute("mgmtData",invValues.get("mgmtData"));
      model.addAttribute("taxPercent",invValues.get("taxPercent"));
      model.addAttribute("taxList", invValues.get("taxList"));
      model.addAttribute("estAmt", dummyEstimation.getInvoiceAmount());
      return "billings_est_create";
    }
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
    public String delete(@PathVariable("id") String id,Model model,
        @ModelAttribute("invoice") Invoice invoice,
        BindingResult bindingResult, RedirectAttributes attr,HttpServletRequest request) {
      logger.debug("delete method starts:");
      Invoice est = invoiceService.findByInvoiceId(id);
      logger.info("Invoice is deleted :" + id);
      attr.addFlashAttribute("message", "MSGSI004");
      attr.addFlashAttribute("invId", id);
      invoiceService.delete(est);
      return "redirect:/invoice/";
    }
    
    @RequestMapping(value = "/searchPdf", method = RequestMethod.POST)
    public void pdf(@RequestParam String country,
        @RequestParam String year, @RequestParam String client,
        @RequestParam String user, HttpServletRequest request, HttpServletResponse response) {
      File logo = new File("resources/images/logo_red_transparent.png");
      if(! logo.exists()){
          logger.warn("File " + logo.getName() + " not exists");
          logger.debug("Real Path :" + serContext.getRealPath("resources/images/"));
      }
      List<Invoice> invList = invoiceService.searchEstListAjax(year, country, client, user);
      logger.debug("invList :" + invList);
      double sum = 0.0d;
      double balSum = 0.0d;
      double estSum = 0.0d;
      List<Estimation> estList = new ArrayList<Estimation>();
      Map<Estimation,Double> estBal = new HashMap<Estimation,Double>();
      for(Invoice inv : invList){
        inv.setFormattedDate(sd.format(inv.getDateOfIssue()));
        String amnt = inv.getInvoiceAmount();
        String bal = inv.getBalance();
        String estAmount = null;
        if(estList.contains(inv.getEstimation())){
          estAmount = "0.00";
          if(Double.parseDouble(bal) < estBal.get(inv.getEstimation())){
            estBal.put(inv.getEstimation(), Double.parseDouble(bal));
          }
        }else {
         estAmount = inv.getEstimation().getEstimationAmount();
         inv.getEstimation().setEstimationAmount(df.format(Double.parseDouble(estAmount)));
         estList.add(inv.getEstimation());
         estBal.put(inv.getEstimation(), Double.parseDouble(bal));
        }
        sum = sum + Double.parseDouble(amnt);
        //balSum = balSum + Double.parseDouble(bal);
        estSum = estSum + Double.parseDouble(estAmount);
        inv.setInvoiceAmount(df.format(Double.parseDouble(amnt)));
        inv.setBalance(df.format(Double.parseDouble(bal)));
        inv.setFormattedDate(sd.format(inv.getDateOfIssue()));
      }
      for (Entry<Estimation, Double> entry : estBal.entrySet()) {
        balSum = balSum + entry.getValue();
      }
      try {
        int yearInt = Integer.parseInt(year);
        String finYear = yearInt + "-" + ((yearInt + 1)+"").substring(2);
        Template template = velocityUtil.getTemplate("templates/invoice_search_pdf.vm");
        VelocityContext vcontext = new VelocityContext();
        vcontext.put("dateOfIssue", sd.format(new Date()));
        vcontext.put("finYear", finYear);
        vcontext.put("invoices", invList);
        /*vcontext.put("startDate", sd.format(inv.getProject().getStartDate()));
        vcontext.put("endDate", sd.format(inv.getProject().getEndDate()));
        vcontext.put("payDate", sd.format(inv.getPlannedPayDate()));
        if(pdfData.get("mgmtData")!= null){
          vcontext.put("mgmtData", ((WorkData) pdfData.get("mgmtData")));
        }
        vcontext.put("tax", pdfData.get("tax"));
        vcontext.put("taxPercent", df.format(Double.parseDouble(pdfData.get("taxPercent")+"")));
        vcontext.put("subTotal", df.format(Double.parseDouble(pdfData.get("subTotal")+"")));
        vcontext.put("total", df.format(Double.parseDouble(pdfData.get("total")+"")));
        vcontext.put("count", inv.getWorkData().size());*/
        if(!country.equals(Constants.COUNTRY_INDIA)){
        vcontext.put("defaultCurrency",  "yen");
        }
        String data = velocityUtil.getData(vcontext, template);
        ITextRenderer renderer = new ITextRenderer();
        logger.debug("Base URL: " + RequestUtil.getBaseUrl(request));
        renderer.setDocumentFromString(data,RequestUtil.getBaseUrl(request)+"resources/images/");
        renderer.layout();
        OutputStream os =  response.getOutputStream();
        renderer.createPDF(os);
        os.close();
      } catch (Exception e) {
        logger.error("Error :" , e);
      }
    }
  }

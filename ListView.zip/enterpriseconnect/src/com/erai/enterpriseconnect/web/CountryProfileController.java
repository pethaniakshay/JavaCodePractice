/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 30-11-2016
 * Author     : Warun
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.repository.CountryRepository;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.CurrencyExchangeService;
import com.erai.enterpriseconnect.service.FinancialYearService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.UserValidator;

/**
 * SalesConnect controller for sales connect
 * 
 * @author Warun
 *
 */
@Controller
public class CountryProfileController {
	
	private final Logger logger = LoggerFactory.getLogger(CountryProfileController.class);
    @Autowired
    private UserService userService;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    BankProfileService bankService;
    
    @Autowired
    FinancialYearService financialYearService;
    
    @Autowired
    CurrencyExchangeService currencyExchangeService;
    
    @Autowired
    CountryRepository countryService;
    
    @Autowired
    UserService userProfile;
    
    
     
    /**
     * Sample method in skeleton - needs modification
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "/country_profile", method = RequestMethod.GET)
    public String listView(@ModelAttribute("command") Country country,
			BindingResult result, Model model) {
      model.addAttribute("isSalesconnect","true");
      
      List<Country> countryList=countryService.findAll();
      List<UserProfile> userList=userProfile.findAll();
      List<BankProfile> bankList=bankService.findAll();
      model.addAttribute("countryList", countryList);
      model.addAttribute("userList", userList);
      model.addAttribute("bankList", bankList);
      return "setting_country_profile";
    }
    
    @RequestMapping(value = "/country_profile_save", method = RequestMethod.GET)
    public String editData(@ModelAttribute("command") Country country,
			BindingResult result, Model model) {
      model.addAttribute("isSalesconnect","true");
      
      List<Country> countryList=countryService.findAll();
      List<UserProfile> userList=userProfile.findAll();
      List<BankProfile> bankList=bankService.findAll();
      model.addAttribute("countryList", countryList);
      model.addAttribute("userList", userList);
      model.addAttribute("bankList", bankList);
      return "setting_country_profile";
    }
    
    // Ajax calling For Find Sales Person
	
  	@RequestMapping(value = "/addSalesPerson", method = RequestMethod.GET)
  	@ResponseBody
  	public String addSalesPerson(HttpServletRequest request){
  			//System.out.println(": "+request.getParameter(""));
  			Long salesPersonId=Long.parseLong(request.getParameter("salesPersonId"));
  			UserProfile serProfile = userProfile.findOne(salesPersonId);
  			String selectedSalePerson="";
  			
  			if(!selectedSalePerson.equals("")){
  				selectedSalePerson=selectedSalePerson+"@,C"+serProfile.getName()+"@,C"+""+"#:@$#"+serProfile.getDateOfJoining();
				}else{
					selectedSalePerson=serProfile.getName()+"@,C"+""+"#:@$#"+serProfile.getDateOfJoining();
				}
  			
  			return selectedSalePerson;
  	}
    
}

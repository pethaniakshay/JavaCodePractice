package com.erai.enterpriseconnect.web;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CountryService;
import com.erai.enterpriseconnect.service.MasterClientStatusServiceImpl;
import com.erai.enterpriseconnect.service.MasterClientTypeService;
import com.erai.enterpriseconnect.service.MasterCountryService;
import com.erai.enterpriseconnect.service.UserService;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * Client Procontroller for sales connect
 * 
 * @author Bishunjay
 *
 */
@Controller
public class UserProfileController {
  private final Logger logger = LoggerFactory
      .getLogger(SalesConnectController.class);
  private static String mapping;
  @Autowired
  private MessageSource messageSource;

  @Autowired
  private MasterCountryService masterCountryService;

  @Autowired
  CountryService countryService;

  @Autowired
  UserService userService;

  @Value("${application.dateFormat}")
  private String dateFormat;

  @RequestMapping(value = "/userProfile", method = RequestMethod.GET)
  public String viewClientProfilePage(
      @ModelAttribute("command") UserProfile userProfile, BindingResult result,
      Model model) {
    Map<String, Object> userView = userService.initUser();
    model.addAttribute("dateFormat", dateFormat);
    model.addAttribute("roles", userView.get("roles"));
    model.addAttribute("empNumber", userView.get("empNumber"));
    model.addAttribute("timezones",DateUtil.getTimeZoneList());
    return "userProfile";
  }

  @RequestMapping(value = "/userProfileSave", method = RequestMethod.POST)
  public String userProfileSave(
      @ModelAttribute("command") UserProfile userProfile, RedirectAttributes attr, BindingResult result,
      Model model, HttpServletRequest request) {
    userService.saveUser(userProfile, request);
    logger.info("User Profile is saved." + userProfile);
    attr.addFlashAttribute("message", "user.save");
    attr.addFlashAttribute("userId", userProfile.getUserProfileId());
    return "redirect:/userProfile/";
  }

}

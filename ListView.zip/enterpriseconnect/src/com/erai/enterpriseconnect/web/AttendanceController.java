/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 30-11-2016
 * Author     : Warun
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.web;


import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.display.ClientDisplay;
import com.erai.enterpriseconnect.display.CountryDisplay;
import com.erai.enterpriseconnect.model.Attendance;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Invoice;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.repository.CountryRepository;
import com.erai.enterpriseconnect.service.AttendanceService;
import com.erai.enterpriseconnect.service.BankProfileService;
import com.erai.enterpriseconnect.service.ClientProfileService;
import com.erai.enterpriseconnect.service.CurrencyExchangeService;
import com.erai.enterpriseconnect.service.FinancialYearService;
import com.erai.enterpriseconnect.service.ProjectService;
import com.erai.enterpriseconnect.service.SecurityService;
import com.erai.enterpriseconnect.service.UserService;
import com.erai.enterpriseconnect.validator.ProjectValidator;
import com.erai.enterpriseconnect.validator.UserValidator;
import com.erai.enterpriseconnect.core.util.VelocityUtil;

/**
 * SalesConnect controller for Project List View
 * 
 * @author Akshay Pethani
 *
 */
@Controller
@RequestMapping(value = "/attendance")
public class AttendanceController {

  private final Logger logger = LoggerFactory.getLogger(AttendanceController.class);
    @Autowired
    private UserService userService;

    
    @Autowired
    private AttendanceService attendanceService;
    
    @Autowired
    private SecurityService securityService;

    @Autowired
    private UserValidator userValidator;
    
    @Autowired
    private MessageSource messageSource;
    
    @Autowired
    BankProfileService bankService;
    
    @Autowired
    FinancialYearService financialYearService;
    
    @Autowired
    CurrencyExchangeService currencyExchangeService;
    
    @Autowired
    CountryRepository countryService;
    
    @Autowired
    UserService userProfile;
    
    @Autowired
    ProjectService projectService;
    
    @Autowired
    ClientProfileService clientProfileService;
    
    @Autowired
    private ProjectValidator projectValidator;
    
    @Autowired
    private VelocityUtil velocityUtil;
    
    @Autowired
    private ServletContext serContext;
    
    @Value("${application.dateFormat}")
    private String dateFormat;
    
    @Value("${application.timeFormat}")
    private String timeFormat;
    
    @InitBinder
    protected void initBinder(WebDataBinder binder) throws Exception {
      SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.APP_DATE_FORMAT);
      CustomDateEditor editor = new CustomDateEditor(dateFormat, true);
      binder.registerCustomEditor(Date.class, editor);
    }
    /**
     * Sample method in skeleton - needs modification
     * 
     * @param model
     * @return
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String listView(@ModelAttribute("command") Attendance attendance,BindingResult result, Model model) {
      logger.debug("Start Attendnace List View ");
      Locale locale = LocaleContextHolder.getLocale();
      model.addAttribute("isEmployeeConnect","true");
      model.addAttribute("isSalesconnect", "true");
      Map<String, Object> attendanceValues = attendanceService.listUsers();
      model.addAttribute("attendanceList",attendanceValues.get("attendance"));
      model.addAttribute("year", attendanceValues.get("year"));
      model.addAttribute("countryList", attendanceValues.get("countryList"));
      model.addAttribute("language", Constants.localMap.get(locale.getLanguage()));
      
 
      return "attendance_lv";
    }
    
    @RequestMapping(value = "/search", method = RequestMethod.POST)
    @ResponseBody
    public String search(@RequestParam String country, @RequestParam String year,
        @RequestParam String month, @RequestParam String pageSize) {
      logger.debug("start search action");
      Locale locale = LocaleContextHolder.getLocale();
      DecimalFormat df = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(locale));
      String data = "error";
      String role = securityService.findLoggedInUserRole();
      logger.debug("country:" + country);
      List<Attendance> attendanceList = attendanceService.searchAttendanceList(year, country, month, role);
      SimpleDateFormat sd = new SimpleDateFormat(dateFormat);
      SimpleDateFormat tf = new SimpleDateFormat(timeFormat);
      for(Attendance att : attendanceList){
        
        att.setFormattedAttDate(sd.format(att.getAttDate()));
        att.setFormattedInTime(tf.format(att.getInTime()));
        att.setFormattedOutTime(tf.format(att.getOutTime()));
     
      }
      
     
      try {
        int pageSizeInt = Integer.parseInt(pageSize);
        Template template = velocityUtil.getTemplate("templates/attendance_lv.vm");
        VelocityContext context = new VelocityContext();
        context.put("attendance", attendanceList);
        Boolean isAdmin = securityService.findLoggedInUserRole().equals(Constants.ROLE_ADMIN)? true : false;
        logger.debug("Is Admin:" +  isAdmin); 
        context.put("isAdmin", isAdmin);
        context.put("lstSize", attendanceList.size());
        logger.debug("List Size: "+ attendanceList.size());
        context.put("pageSize", pageSizeInt);
        context.put("quickEditIcon","<span class=\"fa fa-pencil-square-o\"></span>");
        context.put("contextPath", serContext.getContextPath());
        data = velocityUtil.getData(context, template);
       logger.debug(data);
      } catch (Exception e) {
        logger.error("Error :" + e);
      }
      
      return data;
    }
}

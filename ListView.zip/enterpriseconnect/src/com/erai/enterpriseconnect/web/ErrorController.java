package com.erai.enterpriseconnect.web;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.erai.enterpriceconnect.exception.ERPBusinessException;
import com.erai.enterpriseconnect.model.SystemSetting;
import com.erai.enterpriseconnect.service.BillingsServiceImpl;
import com.erai.enterpriseconnect.service.SystemSettingService;

/**
 * SystemSettingController for changing sales connect page color,background, footer text and image
 * @author user
 *
 */
@Controller
public class ErrorController {

  private final Logger logger = LoggerFactory
      .getLogger(ErrorController.class);

  @Autowired
  private SystemSettingService systemSettingService;

  @Autowired
  private ServletContext context;

  @Autowired
  private MessageSource messageSource;
  
  
  @RequestMapping(value = "/error")
  public String handleResourceNotFoundException() {
    logger.debug("Inside Error");
      return "error";
  }

}

package com.erai.enterpriseconnect.model;

import java.util.Date;


public interface Auditable {

  public String getCreated_user() ;
  public void setCreated_user(String created_user) ;
  public Date getCreated_date() ;
  public void setCreated_date(Date created_date) ;
  public String getUpdated_user() ;
  public void setUpdated_user(String updated_user);
  public Date getUpdated_date(); 
  public void setUpdated_date(Date updated_date);

}

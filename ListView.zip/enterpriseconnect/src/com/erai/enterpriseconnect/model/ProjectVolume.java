/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "project_volume")
public class ProjectVolume {
    private Long volumeId;
    private String volumeName;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="VOLUME_ID")
    public Long getVolumeId() {
        return volumeId;
    }

    public void setVolumeId(Long volumeId) {
        this.volumeId = volumeId;
    }
    
    @Column(name="VOLUME_NAME")
    public String getVolumeName() {
      return volumeName;
    }

    public void setVolumeName(String volumeName) {
      this.volumeName = volumeName;
    }
}

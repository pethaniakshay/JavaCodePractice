package com.erai.enterpriseconnect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "CURRENCY_EXCAHANGE_RATE")
public class CurrencyExchange {

	private Long currencyExchangeId;
	private FinancialYear financialYear;
	private String usd;
	private String jpy;
	private String inr;
	private String createdUser;
	private String updatedUser;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CURRENCY_EXCHANGE_ID")
	public Long getCurrencyExchangeId() {
		return currencyExchangeId;
	}
	public void setCurrencyExchangeId(Long currencyExchangeId) {
		this.currencyExchangeId = currencyExchangeId;
	}
	
	@OneToOne
	@JoinColumn(name = "FINANCIAL_YEAR_ID", referencedColumnName = "FINANCIAL_YEAR_ID")
	public FinancialYear getFinancialYear() {
		return financialYear;
	}
	public void setFinancialYear(FinancialYear financialYear) {
		this.financialYear = financialYear;
	}
	
	@Column(name = "USD")
	public String getUsd() {
		return usd;
	}
	public void setUsd(String usd) {
		this.usd = usd;
	}
	
	@Column(name = "JPY")
	public String getJpy() {
		return jpy;
	}
	public void setJpy(String jpy) {
		this.jpy = jpy;
	}
	
	@Column(name = "INR")
	public String getInr() {
		return inr;
	}
	public void setInr(String inr) {
		this.inr = inr;
	}
	
	@Column(name = "CREATED_USER")
	public String getCreatedUser() {
		return createdUser;
	}
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	
	@Column(name = "UPDATED_USER")
	public String getUpdatedUser() {
		return updatedUser;
	}
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	

}

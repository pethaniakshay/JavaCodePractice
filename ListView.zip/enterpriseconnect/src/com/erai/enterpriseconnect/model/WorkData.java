/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Cascade;

import com.erai.enterpriseconnect.core.util.EncrptBean;
import com.erai.enterpriseconnect.listener.EntityToPersistListener;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "work_data")
@EntityListeners(EntityToPersistListener.class)
public class WorkData implements Auditable,Encryptable{
    private Long workDataId;
    private String particular;
    private Estimation estimation;
    private Invoice invoice;
    private int noOfResources;
    private String tax;
    private String managementCost;
    private ProjectVolume projectVolume;
    private Boolean isWorkData;
    private int displayOrder;
    private String rate;
    private String created_user;
    private Date created_date;
    private String updated_user;
    private Date updated_date;
    private String amount;


    @OneToOne
    @JoinColumn(name = "VOLUME_ID", referencedColumnName = "VOLUME_ID")
    public ProjectVolume getProjectVolume() {
      return projectVolume;
    }

    public void setProjectVolume(ProjectVolume projectVolume) {
      this.projectVolume = projectVolume;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="WORK_DATA_ID")
    public Long getWorkDataId() {
        return workDataId;
    }

    public void setWorkDataId(Long workDataId) {
        this.workDataId = workDataId;
    }
    
    @Column(name="particular")
    public String getParticular() {
      return particular;
    }

    public void setParticular(String particular) {
      this.particular = particular;
    }
    
    @ManyToOne(fetch = FetchType.EAGER,cascade = {CascadeType.ALL})
    @JoinColumn(name = "ESTIMATION_ID", nullable = true)
    public Estimation getEstimation() {
      return this.estimation;
    }

    public void setEstimation(Estimation estimation) {
      this.estimation = estimation;
    }
    
    @ManyToOne(fetch = FetchType.EAGER,cascade = {CascadeType.ALL})
    @JoinColumn(name = "INVOICE_ID", nullable = true)
    public Invoice getInvoice() {
      return this.invoice;
    }

    public void setInvoice(Invoice invoice) {
      this.invoice = invoice;
    }
    
    @Column(name="NO_OF_RESOURCE")
    public int getNoOfResources() {
      return noOfResources;
    }

    public void setNoOfResources(int noOfResources) {
      this.noOfResources = noOfResources;
    }

    @Column(name="RATE")
    public String getRate() {
      return rate;
    }

    public void setRate(String rate) {
      this.rate = rate;
    }

    @Column(name="TAX")
    public String getTax() {
      return tax;
    }

    public void setTax(String tax) {
      this.tax = tax;
    }

    @Column(name="MANAGEMENT_COST")
    public String getManagementCost() {
      return managementCost;
    }

    public void setManagementCost(String managementCost) {
      this.managementCost = managementCost;
    }
    
    @Column(name="IS_WORK_DATA")
    public Boolean getIsWorkData() {
      return isWorkData;
    }

    public void setIsWorkData(Boolean isWorkData) {
      this.isWorkData = isWorkData;
    }
    
    @Column(name="DISPLAY_ORDER")
    public int getDisplayOrder() {
      return displayOrder;
    }

    public void setDisplayOrder(int displayOrder) {
      this.displayOrder = displayOrder;
    }
    @Column(name="CREATED_USER")
    public String getCreated_user() {
      return created_user;
    }
    public void setCreated_user(String created_user) {
      this.created_user = created_user;
    }
    @Column(name="CREATED_DATE")
    public Date getCreated_date() {
      return created_date;
    }
    public void setCreated_date(Date created_date) {
      this.created_date = created_date;
    }
    @Column(name="UPDATED_USER")
    public String getUpdated_user() {
      return updated_user;
    }
    public void setUpdated_user(String updated_user) {
      this.updated_user = updated_user;
    }
    @Column(name="UPDATED_DATE")
    public Date getUpdated_date() {
      return updated_date;
    }
    public void setUpdated_date(Date updated_date) {
      this.updated_date = updated_date;
    }


    @Override
    public String toString() {
    // TODO Auto-generated method stub
    return particular + " " + noOfResources + " " + rate + " " ;
    }

    @Override
    @Transient
    public List<String> getEncryptFieldsInfo() {
      // TODO Auto-generated method stub
      List<String> prop = new ArrayList<String>();
      prop.add("rate");
      return prop;
    }
    
    @Transient
    public String getAmount() {
      return amount;
    }
    @Transient
    public void setAmount(String amount) {
      this.amount = amount;
    }
}

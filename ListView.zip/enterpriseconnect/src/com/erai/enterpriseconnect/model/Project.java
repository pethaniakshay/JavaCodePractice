/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "project")
public class Project {
    private Long projectId;
    private Country country;
    private ClientProfile clientProfile;
    private MasterContractType masterContractType;
    private String projectName;
    private String projectVol;
    private String projectManager;
    private String technologies;
    private String industry;
    private Date startDate;
    private Date endDate;
    private String domain;

    private String projectCode;
    private Set<Resource> resource = new HashSet<Resource>(0);
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="PROJECT_ID")
    public Long getProjectId() {
        return projectId;
    }
    //@JoinColumn(name="projectId", referencedColumnName = "projectId")
    @OneToMany(fetch = FetchType.EAGER,cascade = {CascadeType.ALL} ,mappedBy = "projectId")
    public Set<Resource> getResource() {
		return resource;
	}
    
	public void setResource(Set<Resource> resource) {
		this.resource = resource;
	}

	public void setProjectId(Long projectId) {
        this.projectId = projectId;
    }
    @OneToOne
    @JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
    public Country getCountry() {
      return country;
    }

    public void setCountry(Country country ) {
      this.country = country;
    }
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CLIENT_PROFILE_ID", nullable = false)
    public ClientProfile getClientProfile() {
      return clientProfile;
    }

    public void setClientProfile(ClientProfile clientProfile) {
      this.clientProfile = clientProfile;
    }
    
    @OneToOne
    @JoinColumn(name = "CONTRACT_ID", referencedColumnName = "CONTRACT_ID")
    public MasterContractType getMasterContractType() {
      return masterContractType;
    }

    public void setMasterContractType(MasterContractType masterContractType) {
      this.masterContractType = masterContractType;
    }


    @Column(name="PROJECT_NAME")
    public String getProjectName() {
      return projectName;
    }

    public void setProjectName(String projectName) {
      this.projectName = projectName;
    }

    @Column(name="PROJECT_VOL")
    public String getProjectVol() {
      return projectVol;
    }

    public void setProjectVol(String projectVol) {
      this.projectVol = projectVol;
    }

    @Column(name="PROJECT_MANAGER")
    public String getProjectManager() {
      return projectManager;
    }

    public void setProjectManager(String projectManager) {
      this.projectManager = projectManager;
    }

    @Column(name="TECHNOLOGIES")
    public String getTechnologies() {
      return technologies;
    }

    public void setTechnologies(String technologies) {
      this.technologies = technologies;
    }

    @Column(name="INDUSTRY")
    public String getIndustry() {
      return industry;
    }

    public void setIndustry(String industry) {
      this.industry = industry;
    }

    @Column(name="START_DATE")
    @DateTimeFormat(pattern="yyyy/MM/dd")
    public Date getStartDate() {
      return startDate;
    }

    public void setStartDate(Date startDate) {
      this.startDate = startDate;
    }

    @Column(name="END_DATE")
    @DateTimeFormat(pattern="yyyy/MM/dd")
    public Date getEndDate() {
      return endDate;
    }

    public void setEndDate(Date endDate) {
      this.endDate = endDate;
    }
    
    @Column(name="DOMAIN")
    public String getDomain() {
      return domain;
    }

    public void setDomain(String domain) {
      this.domain = domain;
    }
    
    @Column(name="PROJECT_CODE")
    public String getProjectCode() {
      return projectCode;
    }
    public void setProjectCode(String projectCode) {
      this.projectCode = projectCode;
    }

}

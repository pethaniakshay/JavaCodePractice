/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "mst_payment_terms")
public class MasterPaymentTerms {
    private Long paymentId;
    private String paymentTerms;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="PAYMENT_ID")
    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }
    
    @Column(name="PAYMENT_TERMS")
    public String getPaymentTerms() {
      return paymentTerms;
    }

    public void setPaymentTerms(String paymentTerms) {
      this.paymentTerms = paymentTerms;
    }
}

/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.*;

import java.util.Set;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "mst_tax")
public class MasterTax {
    private Long taxId;
    private String tax;
    private String taxName;
    private MasterCountry mstCountry;

    @OneToOne
    @JoinColumn(name = "MST_COUNTRY_ID", referencedColumnName = "MST_COUNTRY_ID")
    public MasterCountry getMstCountry() {
      return mstCountry;
    }

    public void setMstCountry(MasterCountry mstCountry) {
      this.mstCountry = mstCountry;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="TAX_ID")
    public Long getTaxId() {
        return taxId;
    }

    public void setTaxId(Long taxId) {
        this.taxId = taxId;
    }
    @Column(name="TAX")
    public String getTax() {
      return tax;
    }

    public void setTax(String tax) {
      this.tax = tax;
    }
    
    @Column(name="TAX_NAME")
    public String getTaxName() {
      return taxName;
    }

    public void setTaxName(String taxName) {
      this.taxName = taxName;
    }
    
}

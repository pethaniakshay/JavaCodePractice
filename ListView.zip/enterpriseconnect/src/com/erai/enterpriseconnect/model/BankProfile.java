package com.erai.enterpriseconnect.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bank_profile")
public class BankProfile {

	private Long bankId;
	private Set<ClientProfile> clientProfile;
	private Country country;
	private String bankName;
	private String branchName;
	private String swiftCode;
	//private MasterAccountType accountType;
	private String accountNo;
	private String accountName;
	private String bankAddress;
	private String telephoneNo;
	private String createdUser;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BANK_ID")
	public Long getBankId() {
		return bankId;
	}

	public void setBankId(Long bankId) {
		this.bankId = bankId;
	}

	@Column(name = "BANK_NAME")
	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Column(name = "BRANCH_NAME")
	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Column(name = "SWIFT_CODE")
	public String getSwiftCode() {
		return swiftCode;
	}

	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	@OneToOne
	@JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}
	
	/*@Column(name = "ACCOUNT_TYPE")
	public MasterAccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(MasterAccountType accountType2) {
		this.accountType = accountType2;
	}*/
	
	@Column(name = "ACCOUNT_NUMBER")
	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	@Column(name = "ACCOUNT_NAME")
	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Column(name = "BANK_ADDRESS")
	public String getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

	@Column(name = "TELEPHONE_NO")
	public String getTelephoneNo() {
		return telephoneNo;
	}

	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}

	@Column(name = "CREATED_USER")
	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "bankProfile")
	 public Set<ClientProfile> getClientProfile() {
	    return clientProfile;
	  }

	  public void setClientProfile(Set<ClientProfile> clientProfile) {
	    this.clientProfile = clientProfile;
	  }
	/*@OneToMany(fetch = FetchType.EAGER, mappedBy = "clientProfile")
    public Set<ClientProfile> getClientProfile() {
      return clientProfile;
    }
	public void setClientProfile(Set<ClientProfile> clientProfile) {
		this.clientProfile = clientProfile;
	}*/
}

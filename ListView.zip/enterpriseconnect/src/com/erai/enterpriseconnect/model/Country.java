/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Domain class for EntiTy role
 * 
 * @author anand
 *
 */
@Entity
@Table(name = "country")
public class Country {
    private Long countryId;
    private MasterCountry mstCountry;
    private String cityName;
    private String cityAddress;
    private String zipcode;
    private String telephone;
    private String fax;
    private String logo;
    private String seal;
    private UserProfile userProfile;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="COUNTRY_ID")
    public Long getCountryId() {
        return countryId;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }
    @OneToOne
    @JoinColumn(name = "MST_COUNTRY_ID", referencedColumnName = "MST_COUNTRY_ID")
    public MasterCountry getMstCountry() {
      return mstCountry;
    }

    public void setMstCountry(MasterCountry mstCountry) {
      this.mstCountry = mstCountry;
    }

    @Column(name="CITY_NAME")
    public String getCityName() {
      return cityName;
    }

    public void setCityName(String cityName) {
      this.cityName = cityName;
    }

    @Column(name="CITY_ADDRESS")
    public String getCityAddress() {
      return cityAddress;
    }

    public void setCityAddress(String cityAddress) {
      this.cityAddress = cityAddress;
    }

    @Column(name="ZIP_CODE")
    public String getZipcode() {
      return zipcode;
    }

    public void setZipcode(String zipcode) {
      this.zipcode = zipcode;
    }

    @Column(name="TELEPHONE_NO")
    public String getTelephone() {
      return telephone;
    }

    public void setTelephone(String telephone) {
      this.telephone = telephone;
    }
    @Column(name="FAX_NO")
    public String getFax() {
      return fax;
    }

    public void setFax(String fax) {
      this.fax = fax;
    }

    @Column(name="LOGO_IMG")
    public String getLogo() {
      return logo;
    }

    public void setLogo(String logo) {
      this.logo = logo;
    }
    @Column(name="SEAL_IMG")
    public String getSeal() {
      return seal;
    }

    public void setSeal(String seal) {
      this.seal = seal;
    }
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_PROFILE_ID", nullable = false)
    public UserProfile getUserProfile() {
      return userProfile;
    }

    public void setUserProfile(UserProfile userProfile) {
      this.userProfile = userProfile;
    }
    
}

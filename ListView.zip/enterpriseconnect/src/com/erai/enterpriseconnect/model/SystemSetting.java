package com.erai.enterpriseconnect.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Domain class for SystemSetting
 * 
 * @author user
 *
 */
@Entity
@Table(name = "system_setting")
public class SystemSetting {
  private Long systemSettingId;
  private String footerText;
  private String colorBodyL1;
  private String colorBodyL2;
  private String colorBodyL3;
  private String colorNavi;
  private String colorNaviPhoto;
  private String colorBottonBody;
  private String colorBottonBorder;
  private String backgroundImagPath;
  private String created_user;
  private Date created_date;
  private String updated_user;
  private Date updated_date;
  
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name="SYSTEM_ID")
  public Long getSystemSettingId() {
    return systemSettingId;
  }
  public void setSystemSettingId(Long systemSettingId) {
    this.systemSettingId = systemSettingId;
  }
  
  @Column(name="FOOTER_TEXT")
  public String getFooterText() {
    return footerText;
  }
  public void setFooterText(String footerText) {
    this.footerText = footerText;
  }
  
  @Column(name="COLOR_BODY_L1")
  public String getColorBodyL1() {
    return colorBodyL1;
  }
  public void setColorBodyL1(String colorBodyL1) {
    this.colorBodyL1 = colorBodyL1;
  }
  @Column(name="COLOR_BODY_L2")
  public String getColorBodyL2() {
    return colorBodyL2;
  }
  public void setColorBodyL2(String colorBodyL2) {
    this.colorBodyL2 = colorBodyL2;
  }
  @Column(name="COLOR_BODY_L3")
  public String getColorBodyL3() {
    return colorBodyL3;
  }
  public void setColorBodyL3(String colorBodyL3) {
    this.colorBodyL3 = colorBodyL3;
  }
  
  @Column(name="COLOR_NAVI")
  public String getColorNavi() {
    return colorNavi;
  }
  public void setColorNavi(String colorNavi) {
    this.colorNavi = colorNavi;
  }
  
  @Column(name="COLOR_NAVI_PHOTO")
  public String getColorNaviPhoto() {
    return colorNaviPhoto;
  }
  public void setColorNaviPhoto(String colorNaviPhoto) {
    this.colorNaviPhoto = colorNaviPhoto;
  }
  @Column(name="COLOR_BUTTON_BODY")
  public String getColorBottonBody() {
    return colorBottonBody;
  }
  public void setColorBottonBody(String colorBottonBody) {
    this.colorBottonBody = colorBottonBody;
  }
  @Column(name="COLOR_BUTTON_BOARDER")
  public String getColorBottonBorder() {
    return colorBottonBorder;
  }
  public void setColorBottonBorder(String colorBottonBorder) {
    this.colorBottonBorder = colorBottonBorder;
  }
  @Column(name="BACKGROUND_IMAGE_PATH")
  public String getBackgroundImagPath() {
    return backgroundImagPath;
  }
  public void setBackgroundImagPath(String backgroundImagPath) {
    this.backgroundImagPath = backgroundImagPath;
  }
  @Column(name="CREATED_USER")
  public String getCreated_user() {
    return created_user;
  }
  public void setCreated_user(String created_user) {
    this.created_user = created_user;
  }
  @Column(name="CREATED_DATE")
  public Date getCreated_date() {
    return created_date;
  }
  public void setCreated_date(Date created_date) {
    this.created_date = created_date;
  }
  @Column(name="UPDATED_USER")
  public String getUpdated_user() {
    return updated_user;
  }
  public void setUpdated_user(String updated_user) {
    this.updated_user = updated_user;
  }
  @Column(name="UPDATED_DATE")
  public Date getUpdated_date() {
    return updated_date;
  }
  public void setUpdated_date(Date updated_date) {
    this.updated_date = updated_date;
  }
    
}

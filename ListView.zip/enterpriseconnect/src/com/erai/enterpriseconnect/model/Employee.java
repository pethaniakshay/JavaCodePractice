package com.erai.enterpriseconnect.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Domain class for Entity Resources
 * 
 * @author anand
 *
 */

@Entity
@Table(name="employee")
public class Employee {
	//private FinancialYear financialYear;
	private Long empId;
  private String empName;
	private Date dateOfJoin;
	private String createdUser;
	private String updatedUser;
	private Date updatedDate;
	private Date createdDate;
	private MasterRole mstRole;

  @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="EMP_ID")
	public Long getEmpId() {
    return empId;
  }
  public void setEmpId(Long empId) {
    this.empId = empId;
  }
  @Column(name="EMP_NAME")
  public String getEmpName() {
    return empName;
  }
  public void setEmpName(String empName) {
    this.empName = empName;
  }
  @Column(name="DATE_OF_JOIN")
  public Date getDateOfJoin() {
    return dateOfJoin;
  }
  public void setDateOfJoin(Date dateOfJoin) {
    this.dateOfJoin = dateOfJoin;
  }
  @Column(name="UPDATED_USER")
  public String getUpdatedUser() {
    return updatedUser;
  }
  public void setUpdatedUser(String updatedUser) {
    this.updatedUser = updatedUser;
  }
  @Column(name="UPDATED_DATE")
  public Date getUpdatedDate() {
    return updatedDate;
  }
  public void setUpdatedDate(Date updatedDate) {
    this.updatedDate = updatedDate;
  }
  @Column(name="CREATED_DATE")
  public Date getCreatedDate() {
    return createdDate;
  }
  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }
  @Column(name="CREATED_USER")
  public String getCreatedUser() {
    return createdUser;
  }
  public void setCreatedUser(String createdUser) {
    this.createdUser = createdUser;
  }
  @OneToOne
  @JoinColumn(name = "ROLE_ID", referencedColumnName = "ROLE_ID")
  public MasterRole getMstRole() {
    return mstRole;
  }
  public void setMstRole(MasterRole mstRole) {
    this.mstRole = mstRole;
  }
}

/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.erai.enterpriseconnect.model.UserProfile;

/**
 * Interface for User Service
 * 
 * @author anand
 *
 */
public interface UserService {
  /**
   * @param user
   */
  void save(UserProfile user);

  /**
   * @param username
   * @return
   */
  UserProfile findByEmail(String username);
  
  /**
   * 
   * @param email
   * @return
   */
  UserProfile changePassword(UserProfile user);
  
  List<UserProfile> findAll();
  
  public UserProfile findOne(Long id);
  Map<String,Object> initUser();
  UserProfile findTopByOrderByUserProfileIdDesc();
  
  void saveUser(UserProfile user,HttpServletRequest request);
}

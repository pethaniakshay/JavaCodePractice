/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;
import com.erai.enterpriseconnect.repository.BillingsRepository;
import com.erai.enterpriseconnect.repository.CountryRepository;
import com.erai.enterpriseconnect.repository.MasterCountryRepository;
import com.erai.enterpriseconnect.repository.RoleRepository;
import com.erai.enterpriseconnect.repository.UserRepository;
import com.erai.enterpriseconnect.repository.WorkDataRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * MasterCountryServiceImpl - Country Related details
 * @author anand
 *
 */
@Service
public class WorkDataServiceImpl implements WorkDataService {
    @Autowired
    private WorkDataRepository workDataRepository;

    @Override
    public List<WorkData> findAll() {
      // TODO Auto-generated method stub
      return workDataRepository.findAll();
    }
    
    @Override
    public WorkData findByWorkDataId(long id) {
      // TODO Auto-generated method stub
      return workDataRepository.findByWorkDataId(id);
    }

    @Override
    public void save(WorkData workData) {
      workDataRepository.save(workData);
      
    }

}

package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.repository.MasterClientStatusRepository;

@Service
public class MasterClientStatusServiceImpl implements MasterClientStatusService {

	@Autowired
	private MasterClientStatusRepository masterClientStatusRepository;
	@Override
	public List<MasterClientStatus> findAll() {
		return masterClientStatusRepository.findAll();
	}
	@Override
	public MasterClientStatus findByStatusId(long id) {
		MasterClientStatus masterClientStatus=masterClientStatusRepository.findByStatusId(id);
		return masterClientStatus != null ? masterClientStatus : null;
	}
	
}

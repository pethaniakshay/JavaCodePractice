/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 08-12-2016
 * Author     : Warun
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterContractType;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.ProjectVolume;
import com.erai.enterpriseconnect.model.Resource;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;
import com.erai.enterpriseconnect.repository.ProjectRepository;

/**
 * ProjectServiceImpl - Project Related details
 * 
 * @author Warun
 *
 */
@Service
public class ProjectServiceImpl implements ProjectService {
  
  private final Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);

  @Autowired
  private ProjectRepository projectRepository;
  
  @PersistenceContext
  private EntityManager entityManager;
  
  @Autowired
  private UserService userService;

  @Autowired
  private ClientProfileService clientProfileService;

  @Autowired
  private CountryService countryService;

  @Autowired
  private SecurityService securityService;

  @Autowired
  private WorkDataService workDataService;

  @Autowired
  private MasterContractTypeService masterContractTypeService;

  @Autowired
  private MasterPaymentTermsService masterPaymentTermsService;

  @Autowired
  private ProjectVolumeService projectVolumeService;

  @Autowired
  private MasterCountryService masterCountryService;
  
  @Autowired
  private MasterClientTypeService masterClientTypeService;
  
  @Autowired
  private MasterRoleService masterRoleService;
  
  @Autowired
  private EmployeeService employeeService;
  
  @Value("${application.dateFormat}")
  private String dateFormat;


  @Override
  public List<Project> findAll() {
    // TODO Auto-generated method stub
    return projectRepository.findAll();
  }

  @Override
  public Project findByProjectId(long id) {
    // TODO Auto-generated method stub
    return projectRepository.findByProjectId(id);
  }

  @Override
  public Map<String, Object> initProject() {
    logger.debug("date format :" + dateFormat);
    Map<String, Object> projectView = new HashMap<String, Object>();
    UserProfile userProfile = userService.findByEmail(securityService
        .findLoggedInUsername());
    List<ClientProfile> clients = new ArrayList<ClientProfile>();
    List<MasterClientType> clientTypes = masterClientTypeService.findAll();
    clients.addAll(userProfile.getClientProfile());
    List<MasterContractType> contractTypes = masterContractTypeService.findAll();
    List<ProjectVolume> projectVolumes = projectVolumeService.findAll();
    List<Country> countries = countryService.findByUserProfile(userProfile);
    Project project = new Project();
    project.getResource().add(new Resource());
    projectView.put("project", project);
    projectView.put("clients", clients);
    projectView.put("countries", countries);
    projectView.put("contractTypes", contractTypes);
    projectView.put("clientTypes", clientTypes);
    projectView.put("projectVolumes", projectVolumes);
    projectView.put("defaultCountry",countries.get(0).getMstCountry().getCountryName() );
    projectView.put("roles", masterRoleService.findAll());
    projectView.put("employees", employeeService.findAll());
    return projectView;
  }

  @Override
  public List<Project> findAllByClientProfile(
     ClientProfile clientProfile) {
    // TODO Auto-generated method stub
    return projectRepository.findAllByClientProfile(clientProfile);
  }

  @Override
  public Set<Resource> getResourceData(Map<String, String[]> map) {
    Set<Resource> workSet = new HashSet<Resource>();
    Map<String, Resource> workMap = new HashMap<String, Resource>();
    /*String tax = "";
    if(map.get("taxValue").length > 0){
      tax = map.get("taxValue")[0];
    }*/
    try {
      for (Entry<String, String[]> entry : map.entrySet()) {
        if (entry.getKey().startsWith("resource")
            && (!entry.getValue()[0].equals(""))) {
          String key = entry.getKey();
          String type = key.split("\\.")[1];
          logger.debug("type :" + type);
          logger.debug("key :" + key);
          String index = key.split("\\.")[0].split("resource")[1];
          if (!workMap.containsKey(index)) {
            Resource res = new Resource();
            workMap.put(index, res);
          }
          
          logger.debug("index :" + type);
          switch (type) {
          case "employee":
            long empId = Long.parseLong(entry.getValue()[0]);
            workMap.get(index).setEmployee(employeeService.findByEmpId(empId));
            break;
          case "masterRole":
            long roleId = Long.parseLong(entry.getValue()[0]);
            workMap.get(index).setMasterRole(masterRoleService.findByRoleId(roleId));
            break;
          case "location":
            workMap.get(index).setLocation(entry.getValue()[0]);
            break;
          case "startDate":
            workMap.get(index).setStartDate(DateUtil.getDate(entry.getValue()[0]));
            break;
          case "volume":
            workMap.get(index).setVolume(entry.getValue()[0]);
            break;
          case "endDate":
            workMap.get(index).setEndDate(DateUtil.getDate(entry.getValue()[0]));
            break;
          default:
            break;
          }
        }
      }
      logger.debug("size  :" + workMap.size());
      for (Map.Entry<String, Resource> entry : workMap.entrySet()) {
        Resource workData = (Resource) entry.getValue();
        logger.debug("volume  :" + workData.getVolume());
        logger.debug("start date  :" + workData.getStartDate());
        logger.debug("end Date  :" + workData.getEndDate());
        if((!StringUtils.isEmpty(workData.getVolume())) && 
           (!StringUtils.isEmpty(workData.getStartDate())) && 
           (!StringUtils.isEmpty(workData.getEndDate()))){
          workSet.add(workData);
      } 
      }
      
    } catch (Exception e) {
      e.printStackTrace();
      logger.error("Error:" , e);
    }
    logger.error("success:" + workSet.size());
    return workSet;
  }

  @Override
  public void saveProject(Project project, Set<Resource> resource) {
    for (Resource wrkData : resource) {
      wrkData.setProjectId(project);
      logger.debug("properties :" + wrkData);
    }
    project.setResource(resource);
    logger.debug("size before save: " + project.getResource().size());
    this.save(project);
    
  }

  @Override
  public void save(Project project) {
    projectRepository.save(project);
  }

  @Override
  public Project getProjectDetails(HttpServletRequest request, Project project) {
    // TODO Auto-generated method stub
    String projectId = request.getParameter("projectId");
    if (projectId != null) {
      projectId = projectId.trim();
      project = findByProjectId(Long.parseLong(projectId));
      project.getResource().clear();
    } else {
      project.setProjectCode(project.getProjectName().substring(0, 2) + new SimpleDateFormat("HHmmssSSS").format(new Date()));
      project.setCountry(countryService.findByCountryName(request.getParameter("country.mstCountry.countryName")));
      long clientProfileId = Long.parseLong(request.getParameter("clientProfile.clientProfileId"));
      project.setClientProfile(clientProfileService.findByClientProfileId(clientProfileId));
    }
    project.setProjectName(request.getParameter("projectName"));
    long volumeId = Long.parseLong(request.getParameter("projectVolume"));
    String projectVolume = request.getParameter("volumeNo") + " " + projectVolumeService.findByVolumeId(volumeId).getVolumeName();
    project.setProjectVol(projectVolume);
    project.setProjectManager(request.getParameter("projectManager"));
    long contractId = Long.parseLong(request.getParameter("masterContractType.contractId"));
    project.setMasterContractType(masterContractTypeService.findByContractId(contractId));
    project.setStartDate(DateUtil.getDate(request.getParameter("startDate")));
    project.setEndDate(DateUtil.getDate(request.getParameter("endDate")));
    project.setTechnologies(request.getParameter("technologies"));
    project.setDomain(request.getParameter("endDate"));
    project.setIndustry(request.getParameter("industry"));
    return project;
  }

}

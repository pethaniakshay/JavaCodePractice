package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.MasterClientStatus;

public interface MasterClientStatusService {
	List<MasterClientStatus> findAll();
	MasterClientStatus findByStatusId(long id);
}

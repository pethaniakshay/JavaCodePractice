package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
public interface MasterPaymentTermsService{
	List<MasterPaymentTerms> findAll();
}

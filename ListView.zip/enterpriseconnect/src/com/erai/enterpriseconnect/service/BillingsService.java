/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;

/**
 * Interface for security service
 * 
 * @author anand
 *
 */
public interface BillingsService {
  /**
   * @return username
   */
  List<Estimation> findAll();
  /**
   * @return username
   */
  void save(Estimation estimation);
  
  Estimation merge(Estimation estimation);
  void delete(Estimation estimation);
  
  Estimation findById(String id);
  
  Map<String, Object> createEstimation(Estimation estimation);
  
  Map<String, Object> viewEstimation(Estimation estimation);
  
  List<Estimation> findAllByUserProfile(UserProfile userProfile);
  List<Estimation> findAllByClientProfile(ClientProfile clientProfile);
  
  List<Estimation> searchResult(UserProfile userProfile , int year, String country, String month);
  
  List<Estimation> searchEstimation(UserProfile userProfile1 , int year, String country, ClientProfile clientProfile);
  
  Set<WorkData> getWorkData(Map<String, String[]> map);
  
  void saveEstimation(Set<WorkData> workDataSet,Estimation estimation,String countryCode);
  
  void updateEstimation(Set<WorkData> workDataSet,Estimation estimation,Estimation est,String countryCode);
  
  Map<String, Object> listEstimation();
  
  List<Estimation> searchEstList(String year, String country, String month,String role);
  List<Estimation> searchEstListAjax(String year, String country, String client,String user);
  
  Map<String, Object> search();
}

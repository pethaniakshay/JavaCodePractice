/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Employee;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;

/**
 * Interface for security service
 * 
 * @author anand
 *
 */
public interface EmployeeService {
  /**
   * @return username
   */
  List<Employee> findAll();
  Employee findByEmpId(long EmpId);


}

package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;
import com.erai.enterpriseconnect.repository.MasterClientTypeRepository;
import com.erai.enterpriseconnect.repository.MasterPaymentTermsRepository;
@Service
public class MasterPaymentTermsServiceImpl implements MasterPaymentTermsService {

	@Autowired
	MasterPaymentTermsRepository masterPaymentTermsRepository;
	@Override
	public List<MasterPaymentTerms> findAll() {
		return masterPaymentTermsRepository.findAll();
	}
	
	
}

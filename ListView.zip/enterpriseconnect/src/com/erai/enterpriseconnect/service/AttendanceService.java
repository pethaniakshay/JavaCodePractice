package com.erai.enterpriseconnect.service;

import java.util.List;
import java.util.Map;

import com.erai.enterpriseconnect.model.Attendance;
import com.erai.enterpriseconnect.model.Employee;
import com.erai.enterpriseconnect.model.UserProfile;

public interface AttendanceService {
  
  //List<Attendance> findAll();
  
  List<Attendance> searchResult(Long empID , int year, String country, String month);
  
  Map<String, Object> listUsers();
  
  List<Attendance> searchAttendanceList(String year, String country,String month, String role);

}

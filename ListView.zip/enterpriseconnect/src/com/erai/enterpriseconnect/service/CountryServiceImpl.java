/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.repository.BillingsRepository;
import com.erai.enterpriseconnect.repository.CountryRepository;
import com.erai.enterpriseconnect.repository.MasterCountryRepository;
import com.erai.enterpriseconnect.repository.RoleRepository;
import com.erai.enterpriseconnect.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * MasterCountryServiceImpl - Country Related details
 * @author anand
 *
 */
@Service
public class CountryServiceImpl implements CountryService {
    @Autowired
    private CountryRepository countryRepository;
    
    @Autowired
    private MasterCountryService masterCountryService;

    @Override
    public List<Country> findAll() {
      // TODO Auto-generated method stub
      return countryRepository.findAll();
    }
    
    @Override
    public Country findByCountryId(long id) {
      // TODO Auto-generated method stub
      return countryRepository.findByCountryId(id);
    }

    @Override
    public List<Country> findByUserProfile(UserProfile userProfile) {
      // TODO Auto-generated method stub
      return countryRepository.findByUserProfile(userProfile);
    }

    @Override
    public Country findByCountryName(String name) {
      // TODO Auto-generated method stub
      MasterCountry mstCountry = masterCountryService.findByCountryName(name);
      return countryRepository.findByMstCountry(mstCountry);
    }

    @Override
    public Country findByMasterCountry(MasterCountry masterCountry) {
      // TODO Auto-generated method stub
      return countryRepository.findByMstCountry(masterCountry);
    }

}

/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.repository.BillingsRepository;
import com.erai.enterpriseconnect.repository.ClientProfileRepository;
import com.erai.enterpriseconnect.repository.RoleRepository;
import com.erai.enterpriseconnect.repository.UserRepository;
import com.erai.enterpriseconnect.web.SalesConnectController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

/**
 * UserServiceImpl - User Related details
 * @author anand
 *
 */
@Service
public class ClientProfileServiceImpl implements ClientProfileService {
  
  private final Logger logger = LoggerFactory
      .getLogger(ClientProfileServiceImpl.class);
    @Autowired
    private ClientProfileRepository clientProfileRepository;
    
    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    private MasterCountryService masterCountryService;

    @Autowired
    CountryService countryService;
    
    @Autowired
    private SecurityService securityService;

    @Autowired
    MasterClientStatusServiceImpl masterClientStatusService;

    @Autowired
    MasterClientTypeService masterClientTypeService;

    @Autowired
    BankProfileService bankProfileService;

    @Autowired
    UserService userService;

    @Override
    public List<ClientProfile> findAll() {
      // TODO Auto-generated method stub
      return clientProfileRepository.findAll();
    }

    @Override
    public void save(ClientProfile clientProfile) {
      clientProfileRepository.save(clientProfile);
    }

    @Override
    public ClientProfile findByClientProfileId(long id) {
      // TODO Auto-generated method stub
      return clientProfileRepository.findByClientProfileId(id);
    }
    
    @Override
    public ClientProfile updateClient(ClientProfile clientProfile) {    	
    	ClientProfile existClient = clientProfileRepository.findByClientProfileId(clientProfile.getClientProfileId());
    	//existClient.setWebsite("www.iamvishn.com");
    	//here set all the data and sub data of the clientProfile to existClient and call save
    	existClient.setAddress(clientProfile.getAddress());
    	existClient.setCompanyName(clientProfile.getCompanyName());
    	existClient.setEmail(clientProfile.getEmail());
    	existClient.setTelephoneNo(clientProfile.getTelephoneNo());
    	existClient.setWebsite(clientProfile.getWebsite());
    	existClient.setZipCode(clientProfile.getZipCode());
    	
    	existClient.setBankProfile(clientProfile.getBankProfile());
    	existClient.setCountry(clientProfile.getCountry());
    	existClient.setMasterClientStatus(clientProfile.getMasterClientStatus());
    	existClient.setMasterClientype(clientProfile.getMasterClientype());
    	existClient.setUserProfile(clientProfile.getUserProfile());
    	clientProfileRepository.save(existClient);
      return existClient;
    }

    @Override
    public Map<String, Object> populateInitialData() {
      Map<String, Object> clientValues = new  HashMap<String, Object>();
      // TODO Auto-generated method stub
      List<ClientProfile> clientList = null;
      List<MasterCountry> countryList = null;
      List<MasterClientType> clientTypeList = null;
      List<MasterClientStatus> clientSatausList = null;
      List<BankProfile> bankList = null;
      List<UserProfile> userList = null;
      clientList = clientProfileRepository.findAll();
      logger.info("clientList : " + clientList);
      // country List
      countryList = masterCountryService.findAll();
      logger.info("countryList : " + countryList);
      clientTypeList = masterClientTypeService.findAll();
      logger.info("clientTypeObj : " + clientTypeList);
      clientSatausList = masterClientStatusService.findAll();
      logger.info("clientStatusObj : " + clientSatausList);
      // bank List
      bankList = bankProfileService.findAll();
      logger.info("bankList : " + bankList);
      clientValues.put("countryList", countryList);
      clientValues.put("clientList", clientList);
      clientValues.put("clientStatus", clientSatausList);
      clientValues.put("clientType", clientTypeList);
      clientValues.put("listBank", bankList);
      clientValues.put("userList", userList);
      return clientValues;
    }

    @Override
    public void saveClientProfileData(HttpServletRequest request, ClientProfile clientProfile) {
      // TODO Auto-generated method stub
      BankProfile bankProfile = null;
      MasterCountry masterCountry = null;
      Country country = null;
      MasterClientStatus masterClientStatus = null;
      UserProfile userProfile = null;
      MasterClientType masterClientType = null;
      String clientId = request.getParameter("clientId");
      if (clientId != null) {
        clientId = clientId.trim();
      }
      logger.info("bankId : " + request.getParameter("txtBankID"));// selPaymentBank
      logger.info("txtCountryID : " + request.getParameter("txtCountryID"));// selCountry
      logger.info("txtUserID : " + request.getParameter("txtUserID"));// selUsers
      logger.info("txtClientStatusId : "
          + request.getParameter("txtClientStatusId"));// selClientStatus

      bankProfile = bankProfileService.findOne(Long.parseLong(request
          .getParameter("txtBankID")));
      masterCountry = masterCountryService.findByMstCountryId(Long
          .parseLong(request.getParameter("txtCountryID")));
      country = countryService.findByCountryId(Long.parseLong(request
          .getParameter("txtCountryID")));
      masterClientStatus = masterClientStatusService.findByStatusId(Long
          .parseLong(request.getParameter("txtClientStatusId")));
      userProfile = userService.findOne(Long.parseLong(request
          .getParameter("txtUserID")));
      masterClientType = masterClientTypeService.findByTypeId(1L);// temporary

      clientProfile.setBankProfile(bankProfile);
      logger.info("bankProfile : " + bankProfile);

      country.setMstCountry(masterCountry);
      clientProfile.setCountry(country);
      logger.info("country : " + country);

      clientProfile.setMasterClientStatus(masterClientStatus);
      logger.info("masterClientStatus : " + masterClientStatus);

      clientProfile.setUserProfile(userProfile);
      logger.info("userProfile : " + userProfile);

      clientProfile.setMasterClientype(masterClientType);
      logger.info("masterClientType : " + masterClientType);

      /*
       * This below code will save and update the data base on request basis if
       * client id is found means request has come for the saving else request
       * has come for update operation
       */
      if ("".equals(clientId) || clientId == null) {
        try {
          save(clientProfile);
          logger.info(" clientProfile saved.");
          
        } catch (Exception e) {
          logger.error(" exceptio occured in Client save ",e);
          
        }
      } else {
        clientProfile.setClientProfileId(Long.parseLong(clientId));
        try {
         
         updateClient(clientProfile);
          logger.info(" clientProfile updated.");
          
        } catch (Exception e) {
          logger.error(" exceptio occured in Client update ");
          
        }
      }
      
    }

    @Override
    public List<ClientProfile> findAllByCountry(
        Country country) {
      // TODO Auto-generated method stub
      return clientProfileRepository.findAllByCountry(country);
    }

    @Override
    public List<ClientProfile> findAllByCountryAndUserProfile(Country country,
        UserProfile userProfile) {
      // TODO Auto-generated method stub
      return clientProfileRepository.findAllByCountryAndUserProfile(country,userProfile);
    }

    @Override
    public List<ClientProfile> getClients(Country country) {
      List<ClientProfile > clientProfile = new ArrayList<ClientProfile>();
      String role = securityService.findLoggedInUserRole();
      if(role.equals(Constants.ROLE_ADMIN)){
        clientProfile = findAllByCountry(country);
      } else {
      UserProfile userProfile = userService.findByEmail(securityService
          .findLoggedInUsername());
      clientProfile = findAllByCountryAndUserProfile(country, userProfile);
      logger.debug(" clientProfile" + clientProfile);
      for(ClientProfile cp : clientProfile){
        logger.debug(" clientProfile details" + cp.getCompanyName());
      }
      }
      return clientProfile;
    }

}

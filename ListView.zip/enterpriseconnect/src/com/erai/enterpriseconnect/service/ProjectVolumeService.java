/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.BankProfile;
import com.erai.enterpriseconnect.model.CurrencyExchange;
import com.erai.enterpriseconnect.model.MasterAccountType;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.ProjectVolume;

/**
 * Interface for security service
 * 
 * @author Warun
 *
 */
public interface ProjectVolumeService {
  /**
   * @return username
   */
  List<ProjectVolume> findAll();
  ProjectVolume findByVolumeId(long id);
  
}

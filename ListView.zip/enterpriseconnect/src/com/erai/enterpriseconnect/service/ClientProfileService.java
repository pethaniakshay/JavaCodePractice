/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;

/**
 * Interface for security service
 * 
 * @author anand
 *
 */
public interface ClientProfileService {
  /**
   * @return username
   */
  List<ClientProfile> findAll();
  /**
   * @return username
   */
  void save(ClientProfile clientProfile);
  
  ClientProfile findByClientProfileId(long id);
  
  public ClientProfile updateClient(ClientProfile clientProfile);
  
  Map<String,Object> populateInitialData();
  
  void saveClientProfileData(HttpServletRequest request , ClientProfile clientProfile);
  List<ClientProfile> findAllByCountry(Country country);
  List<ClientProfile> findAllByCountryAndUserProfile(Country country, UserProfile userProfile);
  List<ClientProfile> getClients(Country country);
}

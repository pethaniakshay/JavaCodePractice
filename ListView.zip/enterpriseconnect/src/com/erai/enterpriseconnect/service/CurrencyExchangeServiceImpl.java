/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.erai.enterpriseconnect.model.CurrencyExchange;
import com.erai.enterpriseconnect.repository.CurrencyExchageRepository;

/**
 * Interface for security service
 * 
 * @author warun
 *
 */
@Service
public class CurrencyExchangeServiceImpl implements CurrencyExchangeService {

	@Autowired
	private CurrencyExchageRepository currencyExchageRepository;

	@Override
	public List<CurrencyExchange> save(List<CurrencyExchange> list) {
		// TODO Auto-generated method stub
		return currencyExchageRepository.save(list);
	}

	/**
	 * @return username
	 */

	@Override
	public void addCurrencyExchange(CurrencyExchange currencyExchange) {
		// TODO Auto-generated method stub
		currencyExchageRepository.save(currencyExchange);
	}

	@Override
	@Transactional
	public int updateCurrencyExchange(CurrencyExchange currencyExchange) {
		// TODO Auto-generated method stub
		return currencyExchageRepository.updateAddress(currencyExchange.getUsd(), currencyExchange.getJpy(), currencyExchange.getInr(), currencyExchange.getCurrencyExchangeId());
	}

}

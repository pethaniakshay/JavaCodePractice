/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.model.FinancialYear;
import com.erai.enterpriseconnect.repository.FinancialYearRepository;

/**
 * Interface for security service
 * 
 * @author warun
 *
 */
@Service
public class FinancialYearServiceImpl implements FinancialYearService{
	
	@Autowired
    private FinancialYearRepository financialYearRepository;
	
	@Override
	public FinancialYear findByFinancialYear(String financialYear) {
		// TODO Auto-generated method stub
		return financialYearRepository.findByFinancialYear(financialYear);
	}
  /**
   * @return username
   */

	@Override
	public List<FinancialYear> findAll() {
		// TODO Auto-generated method stub
		return financialYearRepository.findAll();
	}

	

}

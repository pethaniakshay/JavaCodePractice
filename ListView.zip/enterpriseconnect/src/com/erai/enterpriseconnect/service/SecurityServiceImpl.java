/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

/**
 * Security Service Implementation
 * 
 * @author anand
 *
 */
@Service
public class SecurityServiceImpl implements SecurityService {
  @Autowired
  private AuthenticationManager authenticationManager;

  @Autowired
  private UserDetailsService userDetailsService;

  private static final Logger logger = LoggerFactory
      .getLogger(SecurityServiceImpl.class);

  /* Find User logged in by username
   * 
   * @param 
   * @return username
   */
  @Override
  public String findLoggedInUsername() {
    logger.debug("username : " + SecurityContextHolder.getContext().getAuthentication().getName());
    return SecurityContextHolder.getContext().getAuthentication().getName();
  }

  /* Spring security auto login
   * 
   * @param username
   * @param password
   * @return 
   */
  @Override
  public void autologin(String username, String password) {
    UserDetails userDetails = userDetailsService.loadUserByUsername(username);
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
        userDetails, password, userDetails.getAuthorities());
    // Call Authentication
    authenticationManager.authenticate(usernamePasswordAuthenticationToken);
    if (usernamePasswordAuthenticationToken.isAuthenticated()) {
      SecurityContextHolder.getContext().setAuthentication(
          usernamePasswordAuthenticationToken);
      logger.debug(String.format("Auto login %s successfully!", username));
    }
  }

  @Override
  public String findLoggedInUserRole() {
    // TODO Auto-generated method stub
    return  SecurityContextHolder.getContext().getAuthentication().getAuthorities().iterator().next().toString();
  }
}

/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;

import com.erai.enterpriseconnect.model.Country;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;

/**
 * Interface for security service
 * 
 * @author anand
 *
 */
public interface CountryService {
  /**
   * @return username
   */
  List<Country> findAll();

  Country findByCountryId(long id);
  Country findByCountryName(String name);
  Country findByMasterCountry(MasterCountry masterCountry);
  List<Country> findByUserProfile(UserProfile userProfile);

}

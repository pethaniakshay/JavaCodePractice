/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Invoice;
import com.erai.enterpriseconnect.model.UserProfile;
import com.erai.enterpriseconnect.model.WorkData;

/**
 * Interface for security service
 * 
 * @author anand
 *
 */
public interface InvoiceService {
  /**
   * @return username
   */
  List<Invoice> findAll();
  /**
   * @return username
   */
  void save(Invoice invoice);
  
  Invoice merge(Invoice invoice);
  
  Invoice findByInvoiceId(String id);
  
  Map<String, Object> createInvoice(Invoice invoice);
  
  Map<String, Object> viewInvoice(Invoice invoice);
  
  List<Invoice> findAllByUserProfile(UserProfile userProfile);
  
  List<Invoice> findAllByEstimation(Estimation estimation);
  
  List<Invoice> searchResult(UserProfile userProfile , int year, String country, String month);
  
  List<Invoice> searchInvoice(UserProfile userProfile1 , int year, String country, ClientProfile clientProfile);
  
  Set<WorkData> getWorkData(Map<String, String[]> map);
  
  void saveInvoice(Set<WorkData> workDataSet,Invoice invoice,String countryCode);
  
  void updateInvoice(Set<WorkData> workDataSet,Invoice invoice,Invoice inv,String countryCode);
  
  Map<String, Object> listInvoice();
  
  List<Invoice> searchEstList(String year, String country, String month,String role);
  List<Invoice> searchEstListAjax(String year, String country, String client,String user);
  
  Map<String, Object> search();
  void delete(Invoice invoice);
}

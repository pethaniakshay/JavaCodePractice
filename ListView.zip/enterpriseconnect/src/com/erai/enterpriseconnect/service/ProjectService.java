/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 24-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resources;
import javax.servlet.http.HttpServletRequest;

import com.erai.enterpriseconnect.model.ClientProfile;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Project;
import com.erai.enterpriseconnect.model.Resource;
import com.erai.enterpriseconnect.model.WorkData;

/**
 * Interface for security service
 * 
 * @author Warun
 *
 */
public interface ProjectService {
	/**
	 * @return username
	 */
	List<Project> findAll();
	Project findByProjectId(long projId);
	Map<String,Object> initProject();
	List<Project> findAllByClientProfile(ClientProfile clientProfile);
	void saveProject(Project project, Set<Resource> resource);
	Set<Resource> getResourceData(Map<String, String[]> map);
	void save(Project project);
	Project getProjectDetails(HttpServletRequest request,Project project);

}

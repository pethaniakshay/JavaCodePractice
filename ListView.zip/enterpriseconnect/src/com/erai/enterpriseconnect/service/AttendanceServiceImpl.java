package com.erai.enterpriseconnect.service;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erai.enterpriseconnect.core.constants.Constants;
import com.erai.enterpriseconnect.core.util.DateUtil;
import com.erai.enterpriseconnect.model.Attendance;
import com.erai.enterpriseconnect.model.Employee;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.Invoice;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.UserProfile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class AttendanceServiceImpl implements AttendanceService{
  
  private final Logger logger = LoggerFactory.getLogger(AttendanceServiceImpl.class);
  
  @Autowired
  private DateUtil dateUtil;
  
  @PersistenceContext
  private EntityManager entityManager;
  
  @Autowired
  private SecurityService securityService;
  
  @Autowired
  private UserService userService;
  

  @Autowired
  private MasterCountryService masterCountryService;
  
  @Override
  public List<Attendance> searchResult(Long empId, int year, String country, String month){
    String query = "SELECT e FROM Attendance e WHERE e.country.mstCountry.countryName = ? AND e.attDate BETWEEN ? AND ?";
    
    if(empId != null){
      query = query + "AND e.employee.empId = ?";
    }
    
    Query q = entityManager.createQuery(query);
    logger.debug("country:" + country);
    q.setParameter(1, country);
    logger.debug("query :" + query);
    
    switch (month) {
    case "ALL":
      q.setParameter(2, DateUtil.getSqlDate((year+"0401")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0331") , TemporalType.DATE);
         break;
    case "Apr":
      q.setParameter(2, DateUtil.getSqlDate((year+"0401")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year)+"0430") , TemporalType.DATE);
         break;
    case "May":
      q.setParameter(2, DateUtil.getSqlDate((year+"0501")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year)+"0531") , TemporalType.DATE);
         break;
    case "Jun":
      q.setParameter(2, DateUtil.getSqlDate((year+"0601")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year)+"0630") , TemporalType.DATE);
         break;
    case "Jul":
      q.setParameter(2, DateUtil.getSqlDate((year+"0701")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year)+"0731") , TemporalType.DATE);
         break;
    case "Aug":
      q.setParameter(2, DateUtil.getSqlDate((year+"0801")), TemporalType.DATE);
      q.setParameter(3, DateUtil.getSqlDate((year)+"0831") , TemporalType.DATE);
      break;
 case "Sep":
   q.setParameter(2, DateUtil.getSqlDate((year+"0901")), TemporalType.DATE);
   q.setParameter(3, DateUtil.getSqlDate((year)+"0930") , TemporalType.DATE);
      break;
 case "Oct":
   q.setParameter(2, DateUtil.getSqlDate((year+"1001")), TemporalType.DATE);
   q.setParameter(3, DateUtil.getSqlDate((year)+"1031") , TemporalType.DATE);
      break;
 case "Nov":
   q.setParameter(2, DateUtil.getSqlDate((year+"1101")), TemporalType.DATE);
   q.setParameter(3, DateUtil.getSqlDate((year)+"1130") , TemporalType.DATE);
      break;
 case "Dec":
   q.setParameter(2, DateUtil.getSqlDate((year+"1201")), TemporalType.DATE);
   q.setParameter(3, DateUtil.getSqlDate((year)+"1231") , TemporalType.DATE);
      break;
 case "Jan":
   q.setParameter(2, DateUtil.getSqlDate(((year +1)+"0101")), TemporalType.DATE);
   q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0131") , TemporalType.DATE);
case "Feb":
q.setParameter(2, DateUtil.getSqlDate(((year +1)+"0201")), TemporalType.DATE);
if(DateUtil.isLeapYear((year + 1))){
q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0229") , TemporalType.DATE);
} else {
  q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0228") , TemporalType.DATE); 
}
   break;
case "Mar":
q.setParameter(2, DateUtil.getSqlDate(((year +1)+"0301")), TemporalType.DATE);
q.setParameter(3, DateUtil.getSqlDate((year + 1)+"0331") , TemporalType.DATE);
break;
   default:
         break;
   }
    
    if(empId != null){
      q.setParameter(4, empId);
    }
List<Attendance> e = q.getResultList();
    logger.debug("Result List for User :" + e);
    return e; 
  }
  
  public Map<String, Object> listUsers(){
    
    Map<String, Object> attendanceValues = new  HashMap<String, Object>();
    List<Attendance> attendanceList = null;
    int year = Calendar.getInstance().get(Calendar.YEAR);
    String role = securityService.findLoggedInUserRole();
    logger.debug("role:" + role);
    if (role.equals("ROLE_ADMIN")) {
      attendanceList = searchResult(null, year, "JAPAN", "ALL");
    } else {
      
      UserProfile userProfile = userService.findByEmail(securityService.findLoggedInUsername());
      String empNumber = userProfile.getEmpNumber();
      long empID = Long.parseLong(userProfile.getEmpNumber());
      attendanceList = searchResult(empID, year, "JAPAN", "ALL"); 
    }
    logger.debug("attendanceList:" + attendanceList);
    
    // List of countries
    List<MasterCountry> mstCountryList = masterCountryService.findAll();
    attendanceValues.put("attendance", attendanceList);
    attendanceValues.put("year", year);
    attendanceValues.put("countryList",mstCountryList);
    
    return attendanceValues;  
  }
  
  @Override
  public List<Attendance> searchAttendanceList(String year, String country,
      String month, String role) {
    int yearInt = Integer.parseInt(year);
    List<Attendance> attendanceList = null;
   
    logger.debug("country:" + country);
    if (role.equals(Constants.ROLE_ADMIN)) {
      attendanceList = searchResult(null, yearInt, country, month);
    } else {
      UserProfile userProfile = userService.findByEmail(securityService.findLoggedInUsername());
      
      String empNumber = userProfile.getEmpNumber();
      long empID = Long.parseLong(userProfile.getEmpNumber());
      attendanceList = searchResult(empID, yearInt, country, month);
    }
    return attendanceList;
  }
}

package com.erai.enterpriseconnect.core.util;

import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

@Service
public class RequestUtil {
  
  public static String getBaseUrl(HttpServletRequest request){
    StringBuffer url = request.getRequestURL();
    String uri = request.getRequestURI();
    String ctx = request.getContextPath();
    String base = url.substring(0, url.length() - uri.length() + ctx.length()) + "/";
    return base;
  }
}

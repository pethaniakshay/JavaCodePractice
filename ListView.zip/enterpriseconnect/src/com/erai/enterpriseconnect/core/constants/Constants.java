package com.erai.enterpriseconnect.core.constants;

import java.util.HashMap;

public final class Constants {
  public static final String ROLE_ADMIN = "ROLE_ADMIN";
  public static final long ROLE_ADMIN_ID = 1;
  public static final long ROLE_USER_ID = 2;
  public static final String APP_DATE_FORMAT = "yyyy/MM/dd";
  public static final String INV_SUFFIX = "I";
  public static final String COUNTRY_INDIA = "INDIA";
  public final static HashMap localMap = new HashMap();
  static {
    localMap.put("en", "English");
    localMap.put("jp", "Japanese");
}


}

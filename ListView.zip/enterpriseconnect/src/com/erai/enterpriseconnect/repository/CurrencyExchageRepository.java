/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.erai.enterpriseconnect.model.CurrencyExchange;

/**
 * JPA Repository for Bank Profile
 * 
 * @author Warun
 *
 */
@Repository
public interface CurrencyExchageRepository extends JpaRepository<CurrencyExchange, Long>{
  
  List<CurrencyExchange> findAll();
  @Modifying
  @Query("UPDATE CurrencyExchange c SET c.usd = :usd, c.jpy = :jpy, c.inr = :inr WHERE c.currencyExchangeId = :currencyExchangeId")
  int updateAddress(@Param("usd") String usd, @Param("jpy") String jpy, @Param("inr") String inr, @Param("currencyExchangeId") Long currencyExchangeId);
  
}

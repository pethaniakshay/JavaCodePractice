/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.MasterAccountType;

/**
 * JPA Repository for Bank Profile
 * 
 * @author Warun
 *
 */
public interface MasterAccountTypeRepository extends JpaRepository<MasterAccountType, Long>{
  
  List<MasterAccountType> findAll();
  	
}

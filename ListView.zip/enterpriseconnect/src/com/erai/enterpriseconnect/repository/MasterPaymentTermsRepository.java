package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.MasterClientStatus;
import com.erai.enterpriseconnect.model.MasterClientType;
import com.erai.enterpriseconnect.model.MasterContractType;
import com.erai.enterpriseconnect.model.MasterPaymentTerms;

public interface MasterPaymentTermsRepository extends JpaRepository<MasterPaymentTerms, Long> {
	List<MasterPaymentTerms> findAll();
	
}

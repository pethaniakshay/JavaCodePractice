/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import java.util.List;

import com.erai.enterpriseconnect.model.Employee;
import com.erai.enterpriseconnect.model.Estimation;
import com.erai.enterpriseconnect.model.MasterCountry;
import com.erai.enterpriseconnect.model.MasterRole;
import com.erai.enterpriseconnect.model.MasterTax;
import com.erai.enterpriseconnect.model.Role;
import com.erai.enterpriseconnect.model.UserProfile;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * JPA Repository for role
 * 
 * @author anand
 *
 */
public interface EmployeeRepository extends JpaRepository<Employee, Long>{
  
  List<Employee> findAll();
  Employee findByEmpId(long empId);
}

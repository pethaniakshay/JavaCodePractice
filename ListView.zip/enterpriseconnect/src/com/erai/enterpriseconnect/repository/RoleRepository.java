/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import com.erai.enterpriseconnect.model.Role;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * JPA Repository for role
 * 
 * @author anand
 *
 */
public interface RoleRepository extends JpaRepository<Role, Long>{
  Role findById(long id);
}

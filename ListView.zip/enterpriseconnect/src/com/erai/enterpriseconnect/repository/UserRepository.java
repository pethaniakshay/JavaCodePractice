/*
 * Copyright 2016 (C) <Erai Technologies Pvt Ltd>
 * 
 * Created on : 23-11-2016
 * Author     : Anand
 * Version    : 1.0 
 *
 */
package com.erai.enterpriseconnect.repository;

import com.erai.enterpriseconnect.model.UserProfile;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * JPA repository for user
 * 
 * @author anand
 *
 */
public interface UserRepository extends JpaRepository<UserProfile, Long> {
    UserProfile findByEmail(String email);
    public UserProfile findOne(Long id);
    UserProfile findTopByOrderByUserProfileIdDesc();
}

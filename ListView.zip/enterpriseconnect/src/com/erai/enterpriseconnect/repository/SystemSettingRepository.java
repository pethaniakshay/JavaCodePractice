package com.erai.enterpriseconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erai.enterpriseconnect.model.SystemSetting;

/**
 * JpaRepository for SystemSetting
 * 
 * @author user
 *
 */
public interface SystemSettingRepository extends JpaRepository<SystemSetting, Long> {
  @Override
  public List<SystemSetting> findAll();
 }

package com.erai.enterpriceconnect.exception;

public class ERPBusinessException extends RuntimeException { 

}
